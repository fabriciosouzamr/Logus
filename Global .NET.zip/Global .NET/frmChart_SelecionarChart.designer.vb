<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChart_SelecionarChart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.tabChart = New System.Windows.Forms.TabControl
        Me.tbsColuna = New System.Windows.Forms.TabPage
        Me.picColumnChart = New System.Windows.Forms.PictureBox
        Me.picStackColumnChart = New System.Windows.Forms.PictureBox
        Me.picStackBarChart = New System.Windows.Forms.PictureBox
        Me.picStack3DColumnChart = New System.Windows.Forms.PictureBox
        Me.picStack3DBarChart = New System.Windows.Forms.PictureBox
        Me.picBarChart3D = New System.Windows.Forms.PictureBox
        Me.picBarChart = New System.Windows.Forms.PictureBox
        Me.picParetoChart = New System.Windows.Forms.PictureBox
        Me.picCylinderStackColumnChart3D = New System.Windows.Forms.PictureBox
        Me.picCylinderStackBarChart3D = New System.Windows.Forms.PictureBox
        Me.picCylinderColumnChart3D = New System.Windows.Forms.PictureBox
        Me.picCylinderBarChart3D = New System.Windows.Forms.PictureBox
        Me.picColumnLineChart = New System.Windows.Forms.PictureBox
        Me.picColumnChart3D = New System.Windows.Forms.PictureBox
        Me.tbsLinha = New System.Windows.Forms.TabPage
        Me.picScatterLineChart = New System.Windows.Forms.PictureBox
        Me.picRadarChart = New System.Windows.Forms.PictureBox
        Me.picLineChart3D = New System.Windows.Forms.PictureBox
        Me.picLineChart = New System.Windows.Forms.PictureBox
        Me.picStackSplineChart = New System.Windows.Forms.PictureBox
        Me.picStackLineChart = New System.Windows.Forms.PictureBox
        Me.picSplineChart = New System.Windows.Forms.PictureBox
        Me.tbsArea = New System.Windows.Forms.TabPage
        Me.picStepAreaChart = New System.Windows.Forms.PictureBox
        Me.picAreaChart3D = New System.Windows.Forms.PictureBox
        Me.picAreaChart = New System.Windows.Forms.PictureBox
        Me.picStepLineChart = New System.Windows.Forms.PictureBox
        Me.picStackSplineAreaChart = New System.Windows.Forms.PictureBox
        Me.picStackAreaChart = New System.Windows.Forms.PictureBox
        Me.picSplineChart3D = New System.Windows.Forms.PictureBox
        Me.picSplineAreaChart3D = New System.Windows.Forms.PictureBox
        Me.picSplineAreaChart = New System.Windows.Forms.PictureBox
        Me.tbsCone = New System.Windows.Forms.TabPage
        Me.picFunnelChart = New System.Windows.Forms.PictureBox
        Me.picConeChart3D = New System.Windows.Forms.PictureBox
        Me.picPyramidChart3D = New System.Windows.Forms.PictureBox
        Me.picPyramidChart = New System.Windows.Forms.PictureBox
        Me.picFunnelChart3D = New System.Windows.Forms.PictureBox
        Me.tbsOutro = New System.Windows.Forms.TabPage
        Me.picGanttChart = New System.Windows.Forms.PictureBox
        Me.picDoughnutChart3D = New System.Windows.Forms.PictureBox
        Me.picDoughnutChart = New System.Windows.Forms.PictureBox
        Me.picCandleChart = New System.Windows.Forms.PictureBox
        Me.picBubbleChart3D = New System.Windows.Forms.PictureBox
        Me.picBubbleChart = New System.Windows.Forms.PictureBox
        Me.picScatterChart = New System.Windows.Forms.PictureBox
        Me.picProbabilityChart = New System.Windows.Forms.PictureBox
        Me.picPolarChart = New System.Windows.Forms.PictureBox
        Me.picPointChart3D = New System.Windows.Forms.PictureBox
        Me.picPieChart3D = New System.Windows.Forms.PictureBox
        Me.picPieChart = New System.Windows.Forms.PictureBox
        Me.picHeatMapChart3D = New System.Windows.Forms.PictureBox
        Me.picHeatMapChart = New System.Windows.Forms.PictureBox
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.tabChart.SuspendLayout()
        Me.tbsColuna.SuspendLayout()
        CType(Me.picColumnChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackColumnChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackBarChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStack3DColumnChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStack3DBarChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBarChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBarChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picParetoChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCylinderStackColumnChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCylinderStackBarChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCylinderColumnChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCylinderBarChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picColumnLineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picColumnChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbsLinha.SuspendLayout()
        CType(Me.picScatterLineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRadarChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLineChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackSplineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackLineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSplineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbsArea.SuspendLayout()
        CType(Me.picStepAreaChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAreaChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAreaChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStepLineChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackSplineAreaChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStackAreaChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSplineChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSplineAreaChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSplineAreaChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbsCone.SuspendLayout()
        CType(Me.picFunnelChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picConeChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPyramidChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPyramidChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFunnelChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbsOutro.SuspendLayout()
        CType(Me.picGanttChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDoughnutChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDoughnutChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCandleChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBubbleChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBubbleChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picScatterChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picProbabilityChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPolarChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPointChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPieChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPieChart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHeatMapChart3D, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHeatMapChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tabChart
        '
        Me.tabChart.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabChart.Controls.Add(Me.tbsColuna)
        Me.tabChart.Controls.Add(Me.tbsLinha)
        Me.tabChart.Controls.Add(Me.tbsArea)
        Me.tabChart.Controls.Add(Me.tbsCone)
        Me.tabChart.Controls.Add(Me.tbsOutro)
        Me.tabChart.Location = New System.Drawing.Point(5, 5)
        Me.tabChart.Name = "tabChart"
        Me.tabChart.SelectedIndex = 0
        Me.tabChart.Size = New System.Drawing.Size(664, 532)
        Me.tabChart.TabIndex = 0
        '
        'tbsColuna
        '
        Me.tbsColuna.AutoScroll = True
        Me.tbsColuna.Controls.Add(Me.picColumnChart)
        Me.tbsColuna.Controls.Add(Me.picStackColumnChart)
        Me.tbsColuna.Controls.Add(Me.picStackBarChart)
        Me.tbsColuna.Controls.Add(Me.picStack3DColumnChart)
        Me.tbsColuna.Controls.Add(Me.picStack3DBarChart)
        Me.tbsColuna.Controls.Add(Me.picBarChart3D)
        Me.tbsColuna.Controls.Add(Me.picBarChart)
        Me.tbsColuna.Controls.Add(Me.picParetoChart)
        Me.tbsColuna.Controls.Add(Me.picCylinderStackColumnChart3D)
        Me.tbsColuna.Controls.Add(Me.picCylinderStackBarChart3D)
        Me.tbsColuna.Controls.Add(Me.picCylinderColumnChart3D)
        Me.tbsColuna.Controls.Add(Me.picCylinderBarChart3D)
        Me.tbsColuna.Controls.Add(Me.picColumnLineChart)
        Me.tbsColuna.Controls.Add(Me.picColumnChart3D)
        Me.tbsColuna.Location = New System.Drawing.Point(4, 25)
        Me.tbsColuna.Name = "tbsColuna"
        Me.tbsColuna.Padding = New System.Windows.Forms.Padding(3)
        Me.tbsColuna.Size = New System.Drawing.Size(656, 503)
        Me.tbsColuna.TabIndex = 0
        Me.tbsColuna.Tag = "Coluna"
        Me.tbsColuna.Text = "Coluna"
        Me.tbsColuna.UseVisualStyleBackColor = True
        '
        'picColumnChart
        '
        Me.picColumnChart.Location = New System.Drawing.Point(217, 850)
        Me.picColumnChart.Name = "picColumnChart"
        Me.picColumnChart.Size = New System.Drawing.Size(205, 205)
        Me.picColumnChart.TabIndex = 13
        Me.picColumnChart.TabStop = False
        '
        'picStackColumnChart
        '
        Me.picStackColumnChart.Location = New System.Drawing.Point(428, 639)
        Me.picStackColumnChart.Name = "picStackColumnChart"
        Me.picStackColumnChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackColumnChart.TabIndex = 12
        Me.picStackColumnChart.TabStop = False
        '
        'picStackBarChart
        '
        Me.picStackBarChart.Location = New System.Drawing.Point(217, 639)
        Me.picStackBarChart.Name = "picStackBarChart"
        Me.picStackBarChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackBarChart.TabIndex = 11
        Me.picStackBarChart.TabStop = False
        '
        'picStack3DColumnChart
        '
        Me.picStack3DColumnChart.Location = New System.Drawing.Point(428, 428)
        Me.picStack3DColumnChart.Name = "picStack3DColumnChart"
        Me.picStack3DColumnChart.Size = New System.Drawing.Size(205, 205)
        Me.picStack3DColumnChart.TabIndex = 10
        Me.picStack3DColumnChart.TabStop = False
        '
        'picStack3DBarChart
        '
        Me.picStack3DBarChart.Location = New System.Drawing.Point(217, 428)
        Me.picStack3DBarChart.Name = "picStack3DBarChart"
        Me.picStack3DBarChart.Size = New System.Drawing.Size(205, 205)
        Me.picStack3DBarChart.TabIndex = 9
        Me.picStack3DBarChart.TabStop = False
        '
        'picBarChart3D
        '
        Me.picBarChart3D.Location = New System.Drawing.Point(6, 850)
        Me.picBarChart3D.Name = "picBarChart3D"
        Me.picBarChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picBarChart3D.TabIndex = 8
        Me.picBarChart3D.TabStop = False
        '
        'picBarChart
        '
        Me.picBarChart.Location = New System.Drawing.Point(6, 639)
        Me.picBarChart.Name = "picBarChart"
        Me.picBarChart.Size = New System.Drawing.Size(205, 205)
        Me.picBarChart.TabIndex = 7
        Me.picBarChart.TabStop = False
        '
        'picParetoChart
        '
        Me.picParetoChart.Location = New System.Drawing.Point(6, 428)
        Me.picParetoChart.Name = "picParetoChart"
        Me.picParetoChart.Size = New System.Drawing.Size(205, 205)
        Me.picParetoChart.TabIndex = 6
        Me.picParetoChart.TabStop = False
        '
        'picCylinderStackColumnChart3D
        '
        Me.picCylinderStackColumnChart3D.Location = New System.Drawing.Point(428, 217)
        Me.picCylinderStackColumnChart3D.Name = "picCylinderStackColumnChart3D"
        Me.picCylinderStackColumnChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picCylinderStackColumnChart3D.TabIndex = 5
        Me.picCylinderStackColumnChart3D.TabStop = False
        '
        'picCylinderStackBarChart3D
        '
        Me.picCylinderStackBarChart3D.Location = New System.Drawing.Point(217, 217)
        Me.picCylinderStackBarChart3D.Name = "picCylinderStackBarChart3D"
        Me.picCylinderStackBarChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picCylinderStackBarChart3D.TabIndex = 4
        Me.picCylinderStackBarChart3D.TabStop = False
        '
        'picCylinderColumnChart3D
        '
        Me.picCylinderColumnChart3D.Location = New System.Drawing.Point(6, 217)
        Me.picCylinderColumnChart3D.Name = "picCylinderColumnChart3D"
        Me.picCylinderColumnChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picCylinderColumnChart3D.TabIndex = 3
        Me.picCylinderColumnChart3D.TabStop = False
        '
        'picCylinderBarChart3D
        '
        Me.picCylinderBarChart3D.Location = New System.Drawing.Point(428, 6)
        Me.picCylinderBarChart3D.Name = "picCylinderBarChart3D"
        Me.picCylinderBarChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picCylinderBarChart3D.TabIndex = 2
        Me.picCylinderBarChart3D.TabStop = False
        '
        'picColumnLineChart
        '
        Me.picColumnLineChart.Location = New System.Drawing.Point(217, 6)
        Me.picColumnLineChart.Name = "picColumnLineChart"
        Me.picColumnLineChart.Size = New System.Drawing.Size(205, 205)
        Me.picColumnLineChart.TabIndex = 1
        Me.picColumnLineChart.TabStop = False
        '
        'picColumnChart3D
        '
        Me.picColumnChart3D.Location = New System.Drawing.Point(6, 6)
        Me.picColumnChart3D.Name = "picColumnChart3D"
        Me.picColumnChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picColumnChart3D.TabIndex = 0
        Me.picColumnChart3D.TabStop = False
        '
        'tbsLinha
        '
        Me.tbsLinha.AutoScroll = True
        Me.tbsLinha.Controls.Add(Me.picScatterLineChart)
        Me.tbsLinha.Controls.Add(Me.picRadarChart)
        Me.tbsLinha.Controls.Add(Me.picLineChart3D)
        Me.tbsLinha.Controls.Add(Me.picLineChart)
        Me.tbsLinha.Controls.Add(Me.picStackSplineChart)
        Me.tbsLinha.Controls.Add(Me.picStackLineChart)
        Me.tbsLinha.Controls.Add(Me.picSplineChart)
        Me.tbsLinha.Location = New System.Drawing.Point(4, 25)
        Me.tbsLinha.Name = "tbsLinha"
        Me.tbsLinha.Padding = New System.Windows.Forms.Padding(3)
        Me.tbsLinha.Size = New System.Drawing.Size(656, 503)
        Me.tbsLinha.TabIndex = 1
        Me.tbsLinha.Tag = "Linha"
        Me.tbsLinha.Text = "Linha"
        Me.tbsLinha.UseVisualStyleBackColor = True
        '
        'picScatterLineChart
        '
        Me.picScatterLineChart.Location = New System.Drawing.Point(6, 428)
        Me.picScatterLineChart.Name = "picScatterLineChart"
        Me.picScatterLineChart.Size = New System.Drawing.Size(205, 205)
        Me.picScatterLineChart.TabIndex = 12
        Me.picScatterLineChart.TabStop = False
        '
        'picRadarChart
        '
        Me.picRadarChart.Location = New System.Drawing.Point(428, 217)
        Me.picRadarChart.Name = "picRadarChart"
        Me.picRadarChart.Size = New System.Drawing.Size(205, 205)
        Me.picRadarChart.TabIndex = 11
        Me.picRadarChart.TabStop = False
        '
        'picLineChart3D
        '
        Me.picLineChart3D.Location = New System.Drawing.Point(217, 217)
        Me.picLineChart3D.Name = "picLineChart3D"
        Me.picLineChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picLineChart3D.TabIndex = 10
        Me.picLineChart3D.TabStop = False
        '
        'picLineChart
        '
        Me.picLineChart.Location = New System.Drawing.Point(6, 217)
        Me.picLineChart.Name = "picLineChart"
        Me.picLineChart.Size = New System.Drawing.Size(205, 205)
        Me.picLineChart.TabIndex = 9
        Me.picLineChart.TabStop = False
        '
        'picStackSplineChart
        '
        Me.picStackSplineChart.Location = New System.Drawing.Point(428, 6)
        Me.picStackSplineChart.Name = "picStackSplineChart"
        Me.picStackSplineChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackSplineChart.TabIndex = 8
        Me.picStackSplineChart.TabStop = False
        '
        'picStackLineChart
        '
        Me.picStackLineChart.Location = New System.Drawing.Point(217, 6)
        Me.picStackLineChart.Name = "picStackLineChart"
        Me.picStackLineChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackLineChart.TabIndex = 7
        Me.picStackLineChart.TabStop = False
        '
        'picSplineChart
        '
        Me.picSplineChart.Location = New System.Drawing.Point(6, 6)
        Me.picSplineChart.Name = "picSplineChart"
        Me.picSplineChart.Size = New System.Drawing.Size(205, 205)
        Me.picSplineChart.TabIndex = 6
        Me.picSplineChart.TabStop = False
        '
        'tbsArea
        '
        Me.tbsArea.AutoScroll = True
        Me.tbsArea.Controls.Add(Me.picStepAreaChart)
        Me.tbsArea.Controls.Add(Me.picAreaChart3D)
        Me.tbsArea.Controls.Add(Me.picAreaChart)
        Me.tbsArea.Controls.Add(Me.picStepLineChart)
        Me.tbsArea.Controls.Add(Me.picStackSplineAreaChart)
        Me.tbsArea.Controls.Add(Me.picStackAreaChart)
        Me.tbsArea.Controls.Add(Me.picSplineChart3D)
        Me.tbsArea.Controls.Add(Me.picSplineAreaChart3D)
        Me.tbsArea.Controls.Add(Me.picSplineAreaChart)
        Me.tbsArea.Location = New System.Drawing.Point(4, 25)
        Me.tbsArea.Name = "tbsArea"
        Me.tbsArea.Padding = New System.Windows.Forms.Padding(3)
        Me.tbsArea.Size = New System.Drawing.Size(656, 503)
        Me.tbsArea.TabIndex = 2
        Me.tbsArea.Tag = "Area"
        Me.tbsArea.Text = "�rea"
        Me.tbsArea.UseVisualStyleBackColor = True
        '
        'picStepAreaChart
        '
        Me.picStepAreaChart.Location = New System.Drawing.Point(428, 428)
        Me.picStepAreaChart.Name = "picStepAreaChart"
        Me.picStepAreaChart.Size = New System.Drawing.Size(205, 205)
        Me.picStepAreaChart.TabIndex = 20
        Me.picStepAreaChart.TabStop = False
        '
        'picAreaChart3D
        '
        Me.picAreaChart3D.Location = New System.Drawing.Point(217, 428)
        Me.picAreaChart3D.Name = "picAreaChart3D"
        Me.picAreaChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picAreaChart3D.TabIndex = 19
        Me.picAreaChart3D.TabStop = False
        '
        'picAreaChart
        '
        Me.picAreaChart.Location = New System.Drawing.Point(6, 428)
        Me.picAreaChart.Name = "picAreaChart"
        Me.picAreaChart.Size = New System.Drawing.Size(205, 205)
        Me.picAreaChart.TabIndex = 18
        Me.picAreaChart.TabStop = False
        '
        'picStepLineChart
        '
        Me.picStepLineChart.Location = New System.Drawing.Point(428, 217)
        Me.picStepLineChart.Name = "picStepLineChart"
        Me.picStepLineChart.Size = New System.Drawing.Size(205, 205)
        Me.picStepLineChart.TabIndex = 17
        Me.picStepLineChart.TabStop = False
        '
        'picStackSplineAreaChart
        '
        Me.picStackSplineAreaChart.Location = New System.Drawing.Point(217, 217)
        Me.picStackSplineAreaChart.Name = "picStackSplineAreaChart"
        Me.picStackSplineAreaChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackSplineAreaChart.TabIndex = 16
        Me.picStackSplineAreaChart.TabStop = False
        '
        'picStackAreaChart
        '
        Me.picStackAreaChart.Location = New System.Drawing.Point(6, 217)
        Me.picStackAreaChart.Name = "picStackAreaChart"
        Me.picStackAreaChart.Size = New System.Drawing.Size(205, 205)
        Me.picStackAreaChart.TabIndex = 15
        Me.picStackAreaChart.TabStop = False
        '
        'picSplineChart3D
        '
        Me.picSplineChart3D.Location = New System.Drawing.Point(428, 6)
        Me.picSplineChart3D.Name = "picSplineChart3D"
        Me.picSplineChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picSplineChart3D.TabIndex = 14
        Me.picSplineChart3D.TabStop = False
        '
        'picSplineAreaChart3D
        '
        Me.picSplineAreaChart3D.Location = New System.Drawing.Point(217, 6)
        Me.picSplineAreaChart3D.Name = "picSplineAreaChart3D"
        Me.picSplineAreaChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picSplineAreaChart3D.TabIndex = 13
        Me.picSplineAreaChart3D.TabStop = False
        '
        'picSplineAreaChart
        '
        Me.picSplineAreaChart.Location = New System.Drawing.Point(6, 6)
        Me.picSplineAreaChart.Name = "picSplineAreaChart"
        Me.picSplineAreaChart.Size = New System.Drawing.Size(205, 205)
        Me.picSplineAreaChart.TabIndex = 12
        Me.picSplineAreaChart.TabStop = False
        '
        'tbsCone
        '
        Me.tbsCone.Controls.Add(Me.picFunnelChart)
        Me.tbsCone.Controls.Add(Me.picConeChart3D)
        Me.tbsCone.Controls.Add(Me.picPyramidChart3D)
        Me.tbsCone.Controls.Add(Me.picPyramidChart)
        Me.tbsCone.Controls.Add(Me.picFunnelChart3D)
        Me.tbsCone.Location = New System.Drawing.Point(4, 25)
        Me.tbsCone.Name = "tbsCone"
        Me.tbsCone.Padding = New System.Windows.Forms.Padding(3)
        Me.tbsCone.Size = New System.Drawing.Size(656, 503)
        Me.tbsCone.TabIndex = 3
        Me.tbsCone.Tag = "Cone"
        Me.tbsCone.Text = "Cone"
        Me.tbsCone.UseVisualStyleBackColor = True
        '
        'picFunnelChart
        '
        Me.picFunnelChart.Location = New System.Drawing.Point(217, 217)
        Me.picFunnelChart.Name = "picFunnelChart"
        Me.picFunnelChart.Size = New System.Drawing.Size(205, 205)
        Me.picFunnelChart.TabIndex = 21
        Me.picFunnelChart.TabStop = False
        '
        'picConeChart3D
        '
        Me.picConeChart3D.Location = New System.Drawing.Point(6, 217)
        Me.picConeChart3D.Name = "picConeChart3D"
        Me.picConeChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picConeChart3D.TabIndex = 20
        Me.picConeChart3D.TabStop = False
        '
        'picPyramidChart3D
        '
        Me.picPyramidChart3D.Location = New System.Drawing.Point(428, 6)
        Me.picPyramidChart3D.Name = "picPyramidChart3D"
        Me.picPyramidChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picPyramidChart3D.TabIndex = 19
        Me.picPyramidChart3D.TabStop = False
        '
        'picPyramidChart
        '
        Me.picPyramidChart.Location = New System.Drawing.Point(217, 6)
        Me.picPyramidChart.Name = "picPyramidChart"
        Me.picPyramidChart.Size = New System.Drawing.Size(205, 205)
        Me.picPyramidChart.TabIndex = 18
        Me.picPyramidChart.TabStop = False
        '
        'picFunnelChart3D
        '
        Me.picFunnelChart3D.Location = New System.Drawing.Point(6, 6)
        Me.picFunnelChart3D.Name = "picFunnelChart3D"
        Me.picFunnelChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picFunnelChart3D.TabIndex = 17
        Me.picFunnelChart3D.TabStop = False
        '
        'tbsOutro
        '
        Me.tbsOutro.AutoScroll = True
        Me.tbsOutro.Controls.Add(Me.picGanttChart)
        Me.tbsOutro.Controls.Add(Me.picDoughnutChart3D)
        Me.tbsOutro.Controls.Add(Me.picDoughnutChart)
        Me.tbsOutro.Controls.Add(Me.picCandleChart)
        Me.tbsOutro.Controls.Add(Me.picBubbleChart3D)
        Me.tbsOutro.Controls.Add(Me.picBubbleChart)
        Me.tbsOutro.Controls.Add(Me.picScatterChart)
        Me.tbsOutro.Controls.Add(Me.picProbabilityChart)
        Me.tbsOutro.Controls.Add(Me.picPolarChart)
        Me.tbsOutro.Controls.Add(Me.picPointChart3D)
        Me.tbsOutro.Controls.Add(Me.picPieChart3D)
        Me.tbsOutro.Controls.Add(Me.picPieChart)
        Me.tbsOutro.Controls.Add(Me.picHeatMapChart3D)
        Me.tbsOutro.Controls.Add(Me.picHeatMapChart)
        Me.tbsOutro.Location = New System.Drawing.Point(4, 25)
        Me.tbsOutro.Name = "tbsOutro"
        Me.tbsOutro.Padding = New System.Windows.Forms.Padding(3)
        Me.tbsOutro.Size = New System.Drawing.Size(656, 503)
        Me.tbsOutro.TabIndex = 4
        Me.tbsOutro.Tag = "Outros"
        Me.tbsOutro.Text = "Outros"
        Me.tbsOutro.UseVisualStyleBackColor = True
        '
        'picGanttChart
        '
        Me.picGanttChart.Location = New System.Drawing.Point(217, 850)
        Me.picGanttChart.Name = "picGanttChart"
        Me.picGanttChart.Size = New System.Drawing.Size(205, 205)
        Me.picGanttChart.TabIndex = 31
        Me.picGanttChart.TabStop = False
        '
        'picDoughnutChart3D
        '
        Me.picDoughnutChart3D.Location = New System.Drawing.Point(6, 850)
        Me.picDoughnutChart3D.Name = "picDoughnutChart3D"
        Me.picDoughnutChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picDoughnutChart3D.TabIndex = 30
        Me.picDoughnutChart3D.TabStop = False
        '
        'picDoughnutChart
        '
        Me.picDoughnutChart.Location = New System.Drawing.Point(428, 639)
        Me.picDoughnutChart.Name = "picDoughnutChart"
        Me.picDoughnutChart.Size = New System.Drawing.Size(205, 205)
        Me.picDoughnutChart.TabIndex = 29
        Me.picDoughnutChart.TabStop = False
        '
        'picCandleChart
        '
        Me.picCandleChart.Location = New System.Drawing.Point(217, 639)
        Me.picCandleChart.Name = "picCandleChart"
        Me.picCandleChart.Size = New System.Drawing.Size(205, 205)
        Me.picCandleChart.TabIndex = 28
        Me.picCandleChart.TabStop = False
        '
        'picBubbleChart3D
        '
        Me.picBubbleChart3D.Location = New System.Drawing.Point(6, 639)
        Me.picBubbleChart3D.Name = "picBubbleChart3D"
        Me.picBubbleChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picBubbleChart3D.TabIndex = 27
        Me.picBubbleChart3D.TabStop = False
        '
        'picBubbleChart
        '
        Me.picBubbleChart.Location = New System.Drawing.Point(428, 428)
        Me.picBubbleChart.Name = "picBubbleChart"
        Me.picBubbleChart.Size = New System.Drawing.Size(205, 205)
        Me.picBubbleChart.TabIndex = 26
        Me.picBubbleChart.TabStop = False
        '
        'picScatterChart
        '
        Me.picScatterChart.Location = New System.Drawing.Point(217, 428)
        Me.picScatterChart.Name = "picScatterChart"
        Me.picScatterChart.Size = New System.Drawing.Size(205, 205)
        Me.picScatterChart.TabIndex = 25
        Me.picScatterChart.TabStop = False
        '
        'picProbabilityChart
        '
        Me.picProbabilityChart.Location = New System.Drawing.Point(6, 428)
        Me.picProbabilityChart.Name = "picProbabilityChart"
        Me.picProbabilityChart.Size = New System.Drawing.Size(205, 205)
        Me.picProbabilityChart.TabIndex = 24
        Me.picProbabilityChart.TabStop = False
        '
        'picPolarChart
        '
        Me.picPolarChart.Location = New System.Drawing.Point(428, 217)
        Me.picPolarChart.Name = "picPolarChart"
        Me.picPolarChart.Size = New System.Drawing.Size(205, 205)
        Me.picPolarChart.TabIndex = 23
        Me.picPolarChart.TabStop = False
        '
        'picPointChart3D
        '
        Me.picPointChart3D.Location = New System.Drawing.Point(217, 217)
        Me.picPointChart3D.Name = "picPointChart3D"
        Me.picPointChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picPointChart3D.TabIndex = 22
        Me.picPointChart3D.TabStop = False
        '
        'picPieChart3D
        '
        Me.picPieChart3D.Location = New System.Drawing.Point(6, 217)
        Me.picPieChart3D.Name = "picPieChart3D"
        Me.picPieChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picPieChart3D.TabIndex = 21
        Me.picPieChart3D.TabStop = False
        '
        'picPieChart
        '
        Me.picPieChart.Location = New System.Drawing.Point(428, 6)
        Me.picPieChart.Name = "picPieChart"
        Me.picPieChart.Size = New System.Drawing.Size(205, 205)
        Me.picPieChart.TabIndex = 20
        Me.picPieChart.TabStop = False
        '
        'picHeatMapChart3D
        '
        Me.picHeatMapChart3D.Location = New System.Drawing.Point(217, 6)
        Me.picHeatMapChart3D.Name = "picHeatMapChart3D"
        Me.picHeatMapChart3D.Size = New System.Drawing.Size(205, 205)
        Me.picHeatMapChart3D.TabIndex = 19
        Me.picHeatMapChart3D.TabStop = False
        '
        'picHeatMapChart
        '
        Me.picHeatMapChart.Location = New System.Drawing.Point(6, 6)
        Me.picHeatMapChart.Name = "picHeatMapChart"
        Me.picHeatMapChart.Size = New System.Drawing.Size(205, 205)
        Me.picHeatMapChart.TabIndex = 18
        Me.picHeatMapChart.TabStop = False
        '
        'frmChart_SelecionarChart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(674, 540)
        Me.Controls.Add(Me.tabChart)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.Name = "frmChart_SelecionarChart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Selecionar Tipo do Chart"
        Me.tabChart.ResumeLayout(False)
        Me.tbsColuna.ResumeLayout(False)
        CType(Me.picColumnChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackColumnChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackBarChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStack3DColumnChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStack3DBarChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBarChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBarChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picParetoChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCylinderStackColumnChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCylinderStackBarChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCylinderColumnChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCylinderBarChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picColumnLineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picColumnChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbsLinha.ResumeLayout(False)
        CType(Me.picScatterLineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRadarChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLineChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackSplineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackLineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSplineChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbsArea.ResumeLayout(False)
        CType(Me.picStepAreaChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAreaChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAreaChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStepLineChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackSplineAreaChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStackAreaChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSplineChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSplineAreaChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSplineAreaChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbsCone.ResumeLayout(False)
        CType(Me.picFunnelChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picConeChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPyramidChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPyramidChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFunnelChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbsOutro.ResumeLayout(False)
        CType(Me.picGanttChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDoughnutChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDoughnutChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCandleChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBubbleChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBubbleChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picScatterChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picProbabilityChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPolarChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPointChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPieChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPieChart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHeatMapChart3D, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHeatMapChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tbsColuna As System.Windows.Forms.TabPage
    Friend WithEvents tbsLinha As System.Windows.Forms.TabPage
    Friend WithEvents picColumnChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picCylinderStackColumnChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picCylinderStackBarChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picCylinderColumnChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picCylinderBarChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picColumnLineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picParetoChart As System.Windows.Forms.PictureBox
    Friend WithEvents picBarChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picBarChart As System.Windows.Forms.PictureBox
    Friend WithEvents picColumnChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackColumnChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackBarChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStack3DColumnChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStack3DBarChart As System.Windows.Forms.PictureBox
    Friend WithEvents picScatterLineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picRadarChart As System.Windows.Forms.PictureBox
    Friend WithEvents picLineChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picLineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackSplineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackLineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picSplineChart As System.Windows.Forms.PictureBox
    Friend WithEvents tbsArea As System.Windows.Forms.TabPage
    Friend WithEvents picStepLineChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackSplineAreaChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStackAreaChart As System.Windows.Forms.PictureBox
    Friend WithEvents picSplineChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picSplineAreaChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picSplineAreaChart As System.Windows.Forms.PictureBox
    Friend WithEvents picStepAreaChart As System.Windows.Forms.PictureBox
    Friend WithEvents picAreaChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picAreaChart As System.Windows.Forms.PictureBox
    Friend WithEvents tbsCone As System.Windows.Forms.TabPage
    Friend WithEvents picFunnelChart As System.Windows.Forms.PictureBox
    Friend WithEvents picConeChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picPyramidChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picPyramidChart As System.Windows.Forms.PictureBox
    Friend WithEvents picFunnelChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents tbsOutro As System.Windows.Forms.TabPage
    Friend WithEvents picPolarChart As System.Windows.Forms.PictureBox
    Friend WithEvents picPointChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picPieChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picPieChart As System.Windows.Forms.PictureBox
    Friend WithEvents picHeatMapChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picHeatMapChart As System.Windows.Forms.PictureBox
    Friend WithEvents picBubbleChart As System.Windows.Forms.PictureBox
    Friend WithEvents picScatterChart As System.Windows.Forms.PictureBox
    Friend WithEvents picProbabilityChart As System.Windows.Forms.PictureBox
    Friend WithEvents picDoughnutChart As System.Windows.Forms.PictureBox
    Friend WithEvents picCandleChart As System.Windows.Forms.PictureBox
    Friend WithEvents picBubbleChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents picGanttChart As System.Windows.Forms.PictureBox
    Friend WithEvents picDoughnutChart3D As System.Windows.Forms.PictureBox
    Friend WithEvents tabChart As System.Windows.Forms.TabControl
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
