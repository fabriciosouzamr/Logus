Public NotInheritable Class frmConcordo


    

   

    Private Sub cmdNaoConcordo_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNaoConcordo.Click
        End
    End Sub

    Private Sub cmdConcordo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConcordo.Click
        Close()
    End Sub

End Class
