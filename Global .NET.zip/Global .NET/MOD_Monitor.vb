
Public Class AppMonitor
    Implements IMessageFilter

    Private WithEvents tmr As New Timer     ' Timer to check activity status

    ' Last time this appliaction was active
    Private _LastActivity As Date
    Public ReadOnly Property LastActivity() As Date
        Get
            Return _LastActivity
        End Get
    End Property

    Public Sub New()
        ' Add me as a message filter for the application
        Application.AddMessageFilter(Me)

        ' Set interval to 1 second.  
        tmr.Interval = 1000
        tmr.Start()
    End Sub

    Public Function PreFilterMessage(ByRef m As System.Windows.Forms.Message) As Boolean Implements System.Windows.Forms.IMessageFilter.PreFilterMessage
        Const WM_TIMER As Integer = &H113       ' Message ID raised by the timer
        Const WM_PAINT As Integer = &HF                 ' Paint message

        Select Case m.Msg
            Case WM_TIMER
                ' The message has to do with the timer so it shouldn't count
                ' as activity
            Case WM_PAINT
                ' This message tells the form or control to repaint itself
                ' This also shouldn't be considered user activity.
            Case Else
                ' A message has been recieved.  The app is in use so reset _LastActivity
                _LastActivity = Now
        End Select
        Return False
    End Function

    'Esta parametrizado para 15 min
    Private Sub tmr_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles tmr.Tick
        If DateDiff(DateInterval.Minute, _LastActivity, Now) >= 15 Then
            tmr.Stop()
            Main()
            _LastActivity = Now
            tmr.Start()
        End If
    End Sub
End Class
