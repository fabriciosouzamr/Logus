<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Editor
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Editor))
        Dim StateButtonTool1 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Bold", "")
        Dim StateButtonTool2 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Italic", "")
        Dim StateButtonTool3 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Underline", "")
        Dim ContextualTabGroup1 As Infragistics.Win.UltraWinToolbars.ContextualTabGroup = New Infragistics.Win.UltraWinToolbars.ContextualTabGroup("Text")
        Dim Appearance61 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ContextualTabGroup2 As Infragistics.Win.UltraWinToolbars.ContextualTabGroup = New Infragistics.Win.UltraWinToolbars.ContextualTabGroup("Spelling")
        Dim Appearance62 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim RibbonTab1 As Infragistics.Win.UltraWinToolbars.RibbonTab = New Infragistics.Win.UltraWinToolbars.RibbonTab("Format")
        Dim RibbonGroup1 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("TextStyle")
        Dim RibbonGroup2 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("Presets")
        Dim RibbonTab2 As Infragistics.Win.UltraWinToolbars.RibbonTab = New Infragistics.Win.UltraWinToolbars.RibbonTab("Insert")
        Dim RibbonGroup3 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("Images")
        Dim RibbonGroup4 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("Clipboard")
        Dim RibbonTab3 As Infragistics.Win.UltraWinToolbars.RibbonTab = New Infragistics.Win.UltraWinToolbars.RibbonTab("TextTools")
        Dim RibbonGroup5 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("FontDialog")
        Dim RibbonTab4 As Infragistics.Win.UltraWinToolbars.RibbonTab = New Infragistics.Win.UltraWinToolbars.RibbonTab("Tools")
        Dim RibbonGroup6 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("Spelling")
        Dim RibbonTab5 As Infragistics.Win.UltraWinToolbars.RibbonTab = New Infragistics.Win.UltraWinToolbars.RibbonTab("Spelling")
        Dim RibbonGroup7 As Infragistics.Win.UltraWinToolbars.RibbonGroup = New Infragistics.Win.UltraWinToolbars.RibbonGroup("Spelling")
        Dim UltraToolbar1 As Infragistics.Win.UltraWinToolbars.UltraToolbar = New Infragistics.Win.UltraWinToolbars.UltraToolbar("UltraToolbar1")
        Dim StateButtonTool4 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Bold", "")
        Dim Appearance73 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool5 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Italic", "")
        Dim Appearance74 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool6 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Underline", "")
        Dim Appearance75 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool7 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Left", "")
        Dim Appearance77 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool8 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Center", "")
        Dim Appearance78 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool9 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Right", "")
        Dim Appearance79 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool10 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Justify", "")
        Dim UltraToolbar2 As Infragistics.Win.UltraWinToolbars.UltraToolbar = New Infragistics.Win.UltraWinToolbars.UltraToolbar("UltraToolbar2")
        Dim PopupColorPickerTool1 As Infragistics.Win.UltraWinToolbars.PopupColorPickerTool = New Infragistics.Win.UltraWinToolbars.PopupColorPickerTool("FontHighlight")
        Dim PopupColorPickerTool2 As Infragistics.Win.UltraWinToolbars.PopupColorPickerTool = New Infragistics.Win.UltraWinToolbars.PopupColorPickerTool("FontColor")
        Dim PopupGalleryTool1 As Infragistics.Win.UltraWinToolbars.PopupGalleryTool = New Infragistics.Win.UltraWinToolbars.PopupGalleryTool("PresetsGallery")
        Dim ButtonTool1 As Infragistics.Win.UltraWinToolbars.ButtonTool = New Infragistics.Win.UltraWinToolbars.ButtonTool("Imagem")
        Dim UltraToolbar3 As Infragistics.Win.UltraWinToolbars.UltraToolbar = New Infragistics.Win.UltraWinToolbars.UltraToolbar("Tamanho Fonte")
        Dim ComboBoxTool2 As Infragistics.Win.UltraWinToolbars.ComboBoxTool = New Infragistics.Win.UltraWinToolbars.ComboBoxTool("FontSize")
        Dim UltraToolbar4 As Infragistics.Win.UltraWinToolbars.UltraToolbar = New Infragistics.Win.UltraWinToolbars.UltraToolbar("Fonte")
        Dim FontListTool2 As Infragistics.Win.UltraWinToolbars.FontListTool = New Infragistics.Win.UltraWinToolbars.FontListTool("FontName")
        Dim FontListTool4 As Infragistics.Win.UltraWinToolbars.FontListTool = New Infragistics.Win.UltraWinToolbars.FontListTool("FontName")
        Dim PopupColorPickerTool7 As Infragistics.Win.UltraWinToolbars.PopupColorPickerTool = New Infragistics.Win.UltraWinToolbars.PopupColorPickerTool("FontColor")
        Dim Appearance82 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool11 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Bold", "")
        Dim Appearance47 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool12 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Italic", "")
        Dim Appearance48 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool13 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Underline", "")
        Dim Appearance49 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ComboBoxTool4 As Infragistics.Win.UltraWinToolbars.ComboBoxTool = New Infragistics.Win.UltraWinToolbars.ComboBoxTool("FontSize")
        Dim ValueList1 As Infragistics.Win.ValueList = New Infragistics.Win.ValueList(0)
        Dim ValueListItem10 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem11 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem12 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem13 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem14 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem15 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem16 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem17 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem18 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim StateButtonTool14 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Left", "")
        Dim StateButtonTool33 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Center", "")
        Dim StateButtonTool34 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Right", "")
        Dim PopupGalleryTool4 As Infragistics.Win.UltraWinToolbars.PopupGalleryTool = New Infragistics.Win.UltraWinToolbars.PopupGalleryTool("PresetsGallery")
        Dim GalleryToolItem1 As Infragistics.Win.UltraWinToolbars.GalleryToolItem = New Infragistics.Win.UltraWinToolbars.GalleryToolItem("Normal", "")
        Dim Appearance83 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim GalleryToolItem2 As Infragistics.Win.UltraWinToolbars.GalleryToolItem = New Infragistics.Win.UltraWinToolbars.GalleryToolItem("Heading1", "")
        Dim Appearance84 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim GalleryToolItem3 As Infragistics.Win.UltraWinToolbars.GalleryToolItem = New Infragistics.Win.UltraWinToolbars.GalleryToolItem("Heading2", "")
        Dim Appearance85 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim PopupColorPickerTool8 As Infragistics.Win.UltraWinToolbars.PopupColorPickerTool = New Infragistics.Win.UltraWinToolbars.PopupColorPickerTool("FontHighlight")
        Dim Appearance81 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim StateButtonTool35 As Infragistics.Win.UltraWinToolbars.StateButtonTool = New Infragistics.Win.UltraWinToolbars.StateButtonTool("Justify", "")
        Dim Appearance80 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ControlContainerTool2 As Infragistics.Win.UltraWinToolbars.ControlContainerTool = New Infragistics.Win.UltraWinToolbars.ControlContainerTool("ControlContainerTool1")
        Dim ButtonTool2 As Infragistics.Win.UltraWinToolbars.ButtonTool = New Infragistics.Win.UltraWinToolbars.ButtonTool("Imagem")
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ScrollBarLook1 As Infragistics.Win.UltraWinScrollBar.ScrollBarLook = New Infragistics.Win.UltraWinScrollBar.ScrollBarLook
        Me.ListaImagem = New System.Windows.Forms.ImageList(Me.components)
        Me._Editor_Toolbars_Dock_Area_Left = New Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
        Me.tbmFerramenta = New Infragistics.Win.UltraWinToolbars.UltraToolbarsManager(Me.components)
        Me.txtEditor = New Infragistics.Win.FormattedLinkLabel.UltraFormattedTextEditor
        Me._Editor_Toolbars_Dock_Area_Right = New Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
        Me._Editor_Toolbars_Dock_Area_Top = New Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
        Me._Editor_Toolbars_Dock_Area_Bottom = New Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
        Me.Form_Fill_Panel = New System.Windows.Forms.Panel
        Me.UltraSpellChecker1 = New Infragistics.Win.UltraWinSpellChecker.UltraSpellChecker(Me.components)
        CType(Me.tbmFerramenta, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Form_Fill_Panel.SuspendLayout()
        CType(Me.UltraSpellChecker1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListaImagem
        '
        Me.ListaImagem.ImageStream = CType(resources.GetObject("ListaImagem.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ListaImagem.TransparentColor = System.Drawing.Color.White
        Me.ListaImagem.Images.SetKeyName(0, "")
        Me.ListaImagem.Images.SetKeyName(1, "")
        Me.ListaImagem.Images.SetKeyName(2, "")
        Me.ListaImagem.Images.SetKeyName(3, "")
        Me.ListaImagem.Images.SetKeyName(4, "")
        Me.ListaImagem.Images.SetKeyName(5, "")
        Me.ListaImagem.Images.SetKeyName(6, "")
        Me.ListaImagem.Images.SetKeyName(7, "")
        Me.ListaImagem.Images.SetKeyName(8, "")
        Me.ListaImagem.Images.SetKeyName(9, "")
        Me.ListaImagem.Images.SetKeyName(10, "")
        Me.ListaImagem.Images.SetKeyName(11, "")
        Me.ListaImagem.Images.SetKeyName(12, "")
        Me.ListaImagem.Images.SetKeyName(13, "")
        Me.ListaImagem.Images.SetKeyName(14, "")
        Me.ListaImagem.Images.SetKeyName(15, "")
        Me.ListaImagem.Images.SetKeyName(16, "")
        Me.ListaImagem.Images.SetKeyName(17, "")
        Me.ListaImagem.Images.SetKeyName(18, "")
        Me.ListaImagem.Images.SetKeyName(19, "")
        Me.ListaImagem.Images.SetKeyName(20, "")
        Me.ListaImagem.Images.SetKeyName(21, "")
        Me.ListaImagem.Images.SetKeyName(22, "")
        Me.ListaImagem.Images.SetKeyName(23, "")
        Me.ListaImagem.Images.SetKeyName(24, "")
        Me.ListaImagem.Images.SetKeyName(25, "")
        Me.ListaImagem.Images.SetKeyName(26, "")
        Me.ListaImagem.Images.SetKeyName(27, "")
        Me.ListaImagem.Images.SetKeyName(28, "")
        Me.ListaImagem.Images.SetKeyName(29, "")
        Me.ListaImagem.Images.SetKeyName(30, "")
        Me.ListaImagem.Images.SetKeyName(31, "")
        Me.ListaImagem.Images.SetKeyName(32, "")
        Me.ListaImagem.Images.SetKeyName(33, "")
        Me.ListaImagem.Images.SetKeyName(34, "")
        Me.ListaImagem.Images.SetKeyName(35, "")
        Me.ListaImagem.Images.SetKeyName(36, "")
        Me.ListaImagem.Images.SetKeyName(37, "")
        Me.ListaImagem.Images.SetKeyName(38, "")
        Me.ListaImagem.Images.SetKeyName(39, "")
        Me.ListaImagem.Images.SetKeyName(40, "")
        Me.ListaImagem.Images.SetKeyName(41, "")
        Me.ListaImagem.Images.SetKeyName(42, "")
        Me.ListaImagem.Images.SetKeyName(43, "")
        Me.ListaImagem.Images.SetKeyName(44, "")
        Me.ListaImagem.Images.SetKeyName(45, "")
        Me.ListaImagem.Images.SetKeyName(46, "")
        Me.ListaImagem.Images.SetKeyName(47, "Photography.ico")
        '
        '_Editor_Toolbars_Dock_Area_Left
        '
        Me._Editor_Toolbars_Dock_Area_Left.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me._Editor_Toolbars_Dock_Area_Left.BackColor = System.Drawing.SystemColors.Control
        Me._Editor_Toolbars_Dock_Area_Left.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Left
        Me._Editor_Toolbars_Dock_Area_Left.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Editor_Toolbars_Dock_Area_Left.Location = New System.Drawing.Point(0, 27)
        Me._Editor_Toolbars_Dock_Area_Left.Name = "_Editor_Toolbars_Dock_Area_Left"
        Me._Editor_Toolbars_Dock_Area_Left.Size = New System.Drawing.Size(0, 200)
        Me._Editor_Toolbars_Dock_Area_Left.ToolbarsManager = Me.tbmFerramenta
        '
        'tbmFerramenta
        '
        Me.tbmFerramenta.DesignerFlags = 1
        Me.tbmFerramenta.DockWithinContainer = Me
        Me.tbmFerramenta.ImageListSmall = Me.ListaImagem
        Me.tbmFerramenta.MiniToolbar.NonInheritedTools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {StateButtonTool1, StateButtonTool2, StateButtonTool3})
        Me.tbmFerramenta.Office2007UICompatibility = False
        Me.tbmFerramenta.Ribbon.ApplicationMenu.KeyTip = "M"
        Me.tbmFerramenta.Ribbon.ApplicationMenu.ToolAreaRight.Settings.LabelDisplayStyle = Infragistics.Win.UltraWinToolbars.LabelMenuDisplayStyle.Header
        Me.tbmFerramenta.Ribbon.ApplicationMenu.ToolAreaRight.Settings.ShowIconArea = Infragistics.Win.DefaultableBoolean.[True]
        ContextualTabGroup1.Caption = "Selected Text"
        Appearance61.TextHAlignAsString = "Center"
        ContextualTabGroup1.CaptionAppearance = Appearance61
        ContextualTabGroup1.Key = "Text"
        ContextualTabGroup2.Caption = "Spelling"
        Appearance62.TextHAlignAsString = "Center"
        ContextualTabGroup2.CaptionAppearance = Appearance62
        ContextualTabGroup2.Key = "Spelling"
        Me.tbmFerramenta.Ribbon.NonInheritedContextualTabGroups.AddRange(New Infragistics.Win.UltraWinToolbars.ContextualTabGroup() {ContextualTabGroup1, ContextualTabGroup2})
        RibbonTab1.Caption = "Format"
        RibbonGroup1.Caption = "Text Style"
        RibbonGroup1.LayoutDirection = Infragistics.Win.UltraWinToolbars.RibbonGroupToolLayoutDirection.Horizontal
        RibbonGroup2.Caption = "Presets"
        RibbonGroup2.PreferredToolSize = Infragistics.Win.UltraWinToolbars.RibbonToolSize.Large
        RibbonTab1.Groups.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonGroup() {RibbonGroup1, RibbonGroup2})
        RibbonTab1.KeyTip = "F"
        RibbonTab2.Caption = "Insert"
        RibbonGroup3.Caption = "Images"
        RibbonGroup4.Caption = "Clipboard"
        RibbonTab2.Groups.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonGroup() {RibbonGroup3, RibbonGroup4})
        RibbonTab2.KeyTip = "I"
        RibbonTab3.Caption = "Text Tools"
        RibbonTab3.ContextualTabGroupKey = "Text"
        RibbonGroup5.Caption = "Font Dialog"
        RibbonTab3.Groups.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonGroup() {RibbonGroup5})
        RibbonTab3.KeyTip = "TT"
        RibbonTab4.Caption = "Tools"
        RibbonGroup6.Caption = "Spelling"
        RibbonTab4.Groups.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonGroup() {RibbonGroup6})
        RibbonTab4.KeyTip = "T"
        RibbonTab5.Caption = "Spelling"
        RibbonTab5.ContextualTabGroupKey = "Spelling"
        RibbonGroup7.Caption = "Spelling"
        RibbonTab5.Groups.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonGroup() {RibbonGroup7})
        Me.tbmFerramenta.Ribbon.NonInheritedRibbonTabs.AddRange(New Infragistics.Win.UltraWinToolbars.RibbonTab() {RibbonTab1, RibbonTab2, RibbonTab3, RibbonTab4, RibbonTab5})
        Me.tbmFerramenta.ShowFullMenusDelay = 500
        Me.tbmFerramenta.ShowMenuShadows = Infragistics.Win.DefaultableBoolean.[False]
        Me.tbmFerramenta.ShowQuickCustomizeButton = False
        UltraToolbar1.DockedColumn = 3
        UltraToolbar1.DockedRow = 0
        UltraToolbar1.FloatingLocation = New System.Drawing.Point(996, 408)
        UltraToolbar1.FloatingSize = New System.Drawing.Size(284, 26)
        Appearance73.Image = 3
        StateButtonTool4.InstanceProps.AppearancesSmall.Appearance = Appearance73
        Appearance74.Image = 5
        StateButtonTool5.InstanceProps.AppearancesSmall.Appearance = Appearance74
        Appearance75.Image = 4
        StateButtonTool6.InstanceProps.AppearancesSmall.Appearance = Appearance75
        StateButtonTool7.Checked = True
        Appearance77.Image = 0
        StateButtonTool7.InstanceProps.AppearancesSmall.Appearance = Appearance77
        Appearance78.Image = 1
        StateButtonTool8.InstanceProps.AppearancesSmall.Appearance = Appearance78
        Appearance79.Image = 2
        StateButtonTool9.InstanceProps.AppearancesSmall.Appearance = Appearance79
        UltraToolbar1.NonInheritedTools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {StateButtonTool4, StateButtonTool5, StateButtonTool6, StateButtonTool7, StateButtonTool8, StateButtonTool9, StateButtonTool10})
        UltraToolbar1.Text = "UltraToolbar1"
        UltraToolbar2.DockedColumn = 2
        UltraToolbar2.DockedRow = 0
        UltraToolbar2.NonInheritedTools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {PopupColorPickerTool1, PopupColorPickerTool2, PopupGalleryTool1, ButtonTool1})
        UltraToolbar2.Text = "UltraToolbar2"
        UltraToolbar3.DockedColumn = 1
        UltraToolbar3.DockedRow = 0
        ComboBoxTool2.InstanceProps.Width = 50
        UltraToolbar3.NonInheritedTools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {ComboBoxTool2})
        UltraToolbar3.Text = "Tamanho Fonte"
        UltraToolbar4.DockedColumn = 0
        UltraToolbar4.DockedRow = 0
        UltraToolbar4.FloatingSize = New System.Drawing.Size(315, 22)
        FontListTool2.InstanceProps.Width = 181
        UltraToolbar4.NonInheritedTools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {FontListTool2})
        UltraToolbar4.Text = "Fonte"
        Me.tbmFerramenta.Toolbars.AddRange(New Infragistics.Win.UltraWinToolbars.UltraToolbar() {UltraToolbar1, UltraToolbar2, UltraToolbar3, UltraToolbar4})
        FontListTool4.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        FontListTool4.SharedPropsInternal.DisplayStyle = Infragistics.Win.UltraWinToolbars.ToolDisplayStyle.DefaultForToolType
        PopupColorPickerTool7.SelectedColor = System.Drawing.Color.Red
        Appearance82.Image = 41
        PopupColorPickerTool7.SharedPropsInternal.AppearancesSmall.Appearance = Appearance82
        Appearance47.Image = 3
        StateButtonTool11.SharedPropsInternal.AppearancesSmall.Appearance = Appearance47
        Appearance48.Image = 5
        StateButtonTool12.SharedPropsInternal.AppearancesSmall.Appearance = Appearance48
        Appearance49.Image = 4
        StateButtonTool13.SharedPropsInternal.AppearancesSmall.Appearance = Appearance49
        ValueListItem10.DataValue = "10pt"
        ValueListItem10.DisplayText = "10pt"
        ValueListItem11.DataValue = "11pt"
        ValueListItem11.DisplayText = "11pt"
        ValueListItem12.DataValue = "12pt"
        ValueListItem12.DisplayText = "12pt"
        ValueListItem13.DataValue = "13pt"
        ValueListItem13.DisplayText = "13pt"
        ValueListItem14.DataValue = "14pt"
        ValueListItem14.DisplayText = "14pt"
        ValueListItem15.DataValue = "15pt"
        ValueListItem15.DisplayText = "15pt"
        ValueListItem16.DataValue = "16pt"
        ValueListItem16.DisplayText = "16pt"
        ValueListItem17.DataValue = "17pt"
        ValueListItem17.DisplayText = "17pt"
        ValueListItem18.DataValue = "18pt"
        ValueListItem18.DisplayText = "18pt"
        ValueList1.ValueListItems.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem10, ValueListItem11, ValueListItem12, ValueListItem13, ValueListItem14, ValueListItem15, ValueListItem16, ValueListItem17, ValueListItem18})
        ComboBoxTool4.ValueList = ValueList1
        StateButtonTool14.Checked = True
        Appearance83.Image = CType(resources.GetObject("Appearance83.Image"), Object)
        GalleryToolItem1.Settings.Appearance = Appearance83
        GalleryToolItem1.Tag = "color:Black; font-family:Arial; font-weight:normal; font-size:12pt;"
        GalleryToolItem1.ToolTipText = "Normal"
        Appearance84.Image = CType(resources.GetObject("Appearance84.Image"), Object)
        GalleryToolItem2.Settings.Appearance = Appearance84
        GalleryToolItem2.Tag = "color:#025fa4; font-family:Arial;  font-weight:bold; font-size:18pt;"
        GalleryToolItem2.ToolTipText = "Heading 1"
        Appearance85.Image = CType(resources.GetObject("Appearance85.Image"), Object)
        GalleryToolItem3.Settings.Appearance = Appearance85
        GalleryToolItem3.Tag = "color:Maroon; font-family:Arial; font-weight:bold; text-decoration:underline; fon" & _
            "t-size:16pt;"
        GalleryToolItem3.ToolTipText = "Heading 2"
        PopupGalleryTool4.ItemsInternal.AddRange(New Infragistics.Win.UltraWinToolbars.GalleryToolItem() {GalleryToolItem1, GalleryToolItem2, GalleryToolItem3})
        PopupGalleryTool4.ItemStyle = Infragistics.Win.UltraWinToolbars.ItemStyle.StateButton
        PopupGalleryTool4.PreferredDropDownColumns = 2
        PopupGalleryTool4.SharedPropsInternal.Caption = "Presets"
        PopupColorPickerTool8.DropDownArrowStyle = Infragistics.Win.UltraWinToolbars.DropDownArrowStyle.SegmentedStateButton
        PopupColorPickerTool8.ReplaceableColor = System.Drawing.Color.Yellow
        PopupColorPickerTool8.SelectedColor = System.Drawing.Color.Yellow
        Appearance81.Image = CType(resources.GetObject("Appearance81.Image"), Object)
        PopupColorPickerTool8.SharedPropsInternal.AppearancesSmall.Appearance = Appearance81
        Appearance80.Image = 42
        StateButtonTool35.SharedPropsInternal.AppearancesSmall.Appearance = Appearance80
        ControlContainerTool2.SharedPropsInternal.Caption = "ControlContainerTool1"
        Appearance11.Image = My.Resources.Resources.Photography
        ButtonTool2.SharedPropsInternal.AppearancesSmall.Appearance = Appearance11
        ButtonTool2.SharedPropsInternal.Caption = "Imagem"
        Me.tbmFerramenta.Tools.AddRange(New Infragistics.Win.UltraWinToolbars.ToolBase() {FontListTool4, PopupColorPickerTool7, StateButtonTool11, StateButtonTool12, StateButtonTool13, ComboBoxTool4, StateButtonTool14, StateButtonTool33, StateButtonTool34, PopupGalleryTool4, PopupColorPickerTool8, StateButtonTool35, ControlContainerTool2, ButtonTool2})
        '
        'txtEditor
        '
        Me.txtEditor.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid
        Me.tbmFerramenta.SetContextMenuUltra(Me.txtEditor, "FontColor")
        Me.txtEditor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtEditor.Location = New System.Drawing.Point(10, 10)
        Me.txtEditor.Name = "txtEditor"
        ScrollBarLook1.ViewStyle = Infragistics.Win.UltraWinScrollBar.ScrollBarViewStyle.Standard
        Me.txtEditor.ScrollBarLook = ScrollBarLook1
        Me.txtEditor.Size = New System.Drawing.Size(538, 180)
        Me.txtEditor.TabIndex = 1
        Me.txtEditor.TextSectionBreakMode = Infragistics.Win.FormattedLinkLabel.TextSectionBreakMode.Word
        Me.txtEditor.Value = ""
        '
        '_Editor_Toolbars_Dock_Area_Right
        '
        Me._Editor_Toolbars_Dock_Area_Right.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me._Editor_Toolbars_Dock_Area_Right.BackColor = System.Drawing.SystemColors.Control
        Me._Editor_Toolbars_Dock_Area_Right.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Right
        Me._Editor_Toolbars_Dock_Area_Right.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Editor_Toolbars_Dock_Area_Right.Location = New System.Drawing.Point(558, 27)
        Me._Editor_Toolbars_Dock_Area_Right.Name = "_Editor_Toolbars_Dock_Area_Right"
        Me._Editor_Toolbars_Dock_Area_Right.Size = New System.Drawing.Size(0, 200)
        Me._Editor_Toolbars_Dock_Area_Right.ToolbarsManager = Me.tbmFerramenta
        '
        '_Editor_Toolbars_Dock_Area_Top
        '
        Me._Editor_Toolbars_Dock_Area_Top.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me._Editor_Toolbars_Dock_Area_Top.BackColor = System.Drawing.SystemColors.Control
        Me._Editor_Toolbars_Dock_Area_Top.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Top
        Me._Editor_Toolbars_Dock_Area_Top.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Editor_Toolbars_Dock_Area_Top.Location = New System.Drawing.Point(0, 0)
        Me._Editor_Toolbars_Dock_Area_Top.Name = "_Editor_Toolbars_Dock_Area_Top"
        Me._Editor_Toolbars_Dock_Area_Top.Size = New System.Drawing.Size(558, 27)
        Me._Editor_Toolbars_Dock_Area_Top.ToolbarsManager = Me.tbmFerramenta
        '
        '_Editor_Toolbars_Dock_Area_Bottom
        '
        Me._Editor_Toolbars_Dock_Area_Bottom.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me._Editor_Toolbars_Dock_Area_Bottom.BackColor = System.Drawing.SystemColors.Control
        Me._Editor_Toolbars_Dock_Area_Bottom.DockedPosition = Infragistics.Win.UltraWinToolbars.DockedPosition.Bottom
        Me._Editor_Toolbars_Dock_Area_Bottom.ForeColor = System.Drawing.SystemColors.ControlText
        Me._Editor_Toolbars_Dock_Area_Bottom.Location = New System.Drawing.Point(0, 227)
        Me._Editor_Toolbars_Dock_Area_Bottom.Name = "_Editor_Toolbars_Dock_Area_Bottom"
        Me._Editor_Toolbars_Dock_Area_Bottom.Size = New System.Drawing.Size(558, 0)
        Me._Editor_Toolbars_Dock_Area_Bottom.ToolbarsManager = Me.tbmFerramenta
        '
        'Form_Fill_Panel
        '
        Me.Form_Fill_Panel.Controls.Add(Me.txtEditor)
        Me.Form_Fill_Panel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Form_Fill_Panel.Location = New System.Drawing.Point(0, 27)
        Me.Form_Fill_Panel.Name = "Form_Fill_Panel"
        Me.Form_Fill_Panel.Padding = New System.Windows.Forms.Padding(10)
        Me.Form_Fill_Panel.Size = New System.Drawing.Size(558, 200)
        Me.Form_Fill_Panel.TabIndex = 9
        '
        'UltraSpellChecker1
        '
        Me.UltraSpellChecker1.ContainingControl = Me
        '
        'Editor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Form_Fill_Panel)
        Me.Controls.Add(Me._Editor_Toolbars_Dock_Area_Left)
        Me.Controls.Add(Me._Editor_Toolbars_Dock_Area_Right)
        Me.Controls.Add(Me._Editor_Toolbars_Dock_Area_Top)
        Me.Controls.Add(Me._Editor_Toolbars_Dock_Area_Bottom)
        Me.Name = "Editor"
        Me.Size = New System.Drawing.Size(558, 227)
        CType(Me.tbmFerramenta, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Form_Fill_Panel.ResumeLayout(False)
        CType(Me.UltraSpellChecker1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListaImagem As System.Windows.Forms.ImageList
    Friend WithEvents tbmFerramenta As Infragistics.Win.UltraWinToolbars.UltraToolbarsManager
    Friend WithEvents _Editor_Toolbars_Dock_Area_Left As Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
    Friend WithEvents _Editor_Toolbars_Dock_Area_Right As Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
    Friend WithEvents _Editor_Toolbars_Dock_Area_Top As Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
    Friend WithEvents _Editor_Toolbars_Dock_Area_Bottom As Infragistics.Win.UltraWinToolbars.UltraToolbarsDockArea
    Friend WithEvents Form_Fill_Panel As System.Windows.Forms.Panel
    Friend WithEvents txtEditor As Infragistics.Win.FormattedLinkLabel.UltraFormattedTextEditor
    Friend WithEvents UltraSpellChecker1 As Infragistics.Win.UltraWinSpellChecker.UltraSpellChecker
End Class
