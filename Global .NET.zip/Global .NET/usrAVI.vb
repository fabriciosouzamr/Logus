Public Class usrAVI
    Public Sub Inicializar()
        Me.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(238, Byte), CType(249, Byte))
        acFilme.Play()
    End Sub
End Class
