<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChart_Propriedade
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ValueListItem1 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem2 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem3 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem4 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem5 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem6 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem7 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim ValueListItem8 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem9 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim ValueListItem10 As Infragistics.Win.ValueListItem = New Infragistics.Win.ValueListItem
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance
        Dim DockAreaPane1 As Infragistics.Win.UltraWinDock.DockAreaPane = New Infragistics.Win.UltraWinDock.DockAreaPane(Infragistics.Win.UltraWinDock.DockedLocation.DockedRight, New System.Guid("d326267f-c8d4-4981-a571-dc550479d578"))
        Dim DockableControlPane1 As Infragistics.Win.UltraWinDock.DockableControlPane = New Infragistics.Win.UltraWinDock.DockableControlPane(New System.Guid("4479b956-7f6d-4d4f-9a98-4fdcf5989a40"), New System.Guid("00000000-0000-0000-0000-000000000000"), -1, New System.Guid("d326267f-c8d4-4981-a571-dc550479d578"), -1)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmChart_Propriedade))
        Me.grpPropriedades = New Infragistics.Win.Misc.UltraGroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.tickPercentageEditor = New Infragistics.Win.UltraWinEditors.UltraNumericEditor
        Me.label4 = New System.Windows.Forms.Label
        Me.tickIntervalTypeEditor = New Infragistics.Win.UltraWinEditors.UltraComboEditor
        Me.label3 = New System.Windows.Forms.Label
        Me.tickIntervalEditor = New Infragistics.Win.UltraWinEditors.UltraNumericEditor
        Me.label2 = New System.Windows.Forms.Label
        Me.tickmarkStyleEditor = New Infragistics.Win.UltraWinEditors.UltraComboEditor
        Me.Label5 = New System.Windows.Forms.Label
        Me.cboModeloEstiloCor = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.grpRolagem = New System.Windows.Forms.GroupBox
        Me.chkRolagem = New System.Windows.Forms.CheckBox
        Me.trbRolagemVertical = New System.Windows.Forms.TrackBar
        Me.UltraLabel4 = New Infragistics.Win.Misc.UltraLabel
        Me.trbRolagemHorizontal = New System.Windows.Forms.TrackBar
        Me.UltraLabel5 = New Infragistics.Win.Misc.UltraLabel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.chkLinhaHorizontalMenor = New System.Windows.Forms.CheckBox
        Me.chkLinhaVerticalMenor = New System.Windows.Forms.CheckBox
        Me.chkLinhaVerticalMaior = New System.Windows.Forms.CheckBox
        Me.chkLinhaHorizontalMaior = New System.Windows.Forms.CheckBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.trbEscala_Perspectiva = New System.Windows.Forms.TrackBar
        Me.label9 = New System.Windows.Forms.Label
        Me.label10 = New System.Windows.Forms.Label
        Me.trbEscala_Escala = New System.Windows.Forms.TrackBar
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label0 = New Infragistics.Win.Misc.UltraLabel
        Me.ultraLabel6 = New Infragistics.Win.Misc.UltraLabel
        Me.trbExtensao_Horizontal = New System.Windows.Forms.TrackBar
        Me.trbExtensao_Vertical = New System.Windows.Forms.TrackBar
        Me.grpRotacao = New System.Windows.Forms.GroupBox
        Me.UltraLabel3 = New Infragistics.Win.Misc.UltraLabel
        Me.UltraLabel2 = New Infragistics.Win.Misc.UltraLabel
        Me.UltraLabel1 = New Infragistics.Win.Misc.UltraLabel
        Me.trbRotacaoGiratoria = New System.Windows.Forms.TrackBar
        Me.trbRotacaoHorizontal = New System.Windows.Forms.TrackBar
        Me.trbRotacaoVertical = New System.Windows.Forms.TrackBar
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.UltraDockManager1 = New Infragistics.Win.UltraWinDock.UltraDockManager(Me.components)
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft = New Infragistics.Win.UltraWinDock.UnpinnedTabArea
        Me._frmChart_PropriedadeUnpinnedTabAreaRight = New Infragistics.Win.UltraWinDock.UnpinnedTabArea
        Me._frmChart_PropriedadeUnpinnedTabAreaTop = New Infragistics.Win.UltraWinDock.UnpinnedTabArea
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom = New Infragistics.Win.UltraWinDock.UnpinnedTabArea
        Me._frmChart_PropriedadeAutoHideControl = New Infragistics.Win.UltraWinDock.AutoHideControl
        Me.DockableWindow1 = New Infragistics.Win.UltraWinDock.DockableWindow
        Me.WindowDockingArea1 = New Infragistics.Win.UltraWinDock.WindowDockingArea
        CType(Me.grpPropriedades, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPropriedades.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.tickPercentageEditor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tickIntervalTypeEditor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tickIntervalEditor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tickmarkStyleEditor, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRolagem.SuspendLayout()
        CType(Me.trbRolagemVertical, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbRolagemHorizontal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.trbEscala_Perspectiva, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbEscala_Escala, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.trbExtensao_Horizontal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbExtensao_Vertical, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRotacao.SuspendLayout()
        CType(Me.trbRotacaoGiratoria, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbRotacaoHorizontal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trbRotacaoVertical, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UltraDockManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._frmChart_PropriedadeAutoHideControl.SuspendLayout()
        Me.DockableWindow1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpPropriedades
        '
        Me.grpPropriedades.Controls.Add(Me.GroupBox3)
        Me.grpPropriedades.Controls.Add(Me.cboModeloEstiloCor)
        Me.grpPropriedades.Controls.Add(Me.Label1)
        Me.grpPropriedades.Controls.Add(Me.grpRolagem)
        Me.grpPropriedades.Controls.Add(Me.GroupBox1)
        Me.grpPropriedades.Controls.Add(Me.GroupBox4)
        Me.grpPropriedades.Controls.Add(Me.GroupBox2)
        Me.grpPropriedades.Controls.Add(Me.grpRotacao)
        Me.grpPropriedades.Location = New System.Drawing.Point(0, 26)
        Me.grpPropriedades.Name = "grpPropriedades"
        Me.grpPropriedades.Size = New System.Drawing.Size(379, 858)
        Me.grpPropriedades.TabIndex = 86
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.tickPercentageEditor)
        Me.GroupBox3.Controls.Add(Me.label4)
        Me.GroupBox3.Controls.Add(Me.tickIntervalTypeEditor)
        Me.GroupBox3.Controls.Add(Me.label3)
        Me.GroupBox3.Controls.Add(Me.tickIntervalEditor)
        Me.GroupBox3.Controls.Add(Me.label2)
        Me.GroupBox3.Controls.Add(Me.tickmarkStyleEditor)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Location = New System.Drawing.Point(190, 64)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(176, 203)
        Me.GroupBox3.TabIndex = 31
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Configura��o Data e Hora"
        '
        'tickPercentageEditor
        '
        Appearance1.BackColor = System.Drawing.Color.White
        Me.tickPercentageEditor.Appearance = Appearance1
        Me.tickPercentageEditor.BackColor = System.Drawing.Color.White
        Me.tickPercentageEditor.Location = New System.Drawing.Point(13, 168)
        Me.tickPercentageEditor.Name = "tickPercentageEditor"
        Me.tickPercentageEditor.NumericType = Infragistics.Win.UltraWinEditors.NumericType.[Double]
        Me.tickPercentageEditor.Size = New System.Drawing.Size(92, 21)
        Me.tickPercentageEditor.TabIndex = 33
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(13, 153)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(136, 13)
        Me.label4.TabIndex = 37
        Me.label4.Text = "Porcentagem de Marca��o"
        '
        'tickIntervalTypeEditor
        '
        Me.tickIntervalTypeEditor.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem1.DataValue = "NotSet"
        ValueListItem1.DisplayText = "N�o definido"
        ValueListItem2.DataValue = "Minutes"
        ValueListItem2.DisplayText = "Minutos"
        ValueListItem3.DataValue = "Hours"
        ValueListItem3.DisplayText = "Horas"
        ValueListItem4.DataValue = "Days"
        ValueListItem4.DisplayText = "Dias"
        ValueListItem5.DataValue = "Weeks"
        ValueListItem5.DisplayText = "Semanas"
        ValueListItem6.DataValue = "Months"
        ValueListItem6.DisplayText = "Meses"
        ValueListItem7.DataValue = "Years"
        ValueListItem7.DisplayText = "Anos"
        Me.tickIntervalTypeEditor.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem1, ValueListItem2, ValueListItem3, ValueListItem4, ValueListItem5, ValueListItem6, ValueListItem7})
        Me.tickIntervalTypeEditor.Location = New System.Drawing.Point(13, 124)
        Me.tickIntervalTypeEditor.Name = "tickIntervalTypeEditor"
        Me.tickIntervalTypeEditor.Nullable = False
        Me.tickIntervalTypeEditor.Size = New System.Drawing.Size(104, 21)
        Me.tickIntervalTypeEditor.TabIndex = 30
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(13, 109)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(102, 14)
        Me.label3.TabIndex = 36
        Me.label3.Text = "Tipo de Intervalo"
        '
        'tickIntervalEditor
        '
        Appearance2.BackColor = System.Drawing.Color.White
        Me.tickIntervalEditor.Appearance = Appearance2
        Me.tickIntervalEditor.BackColor = System.Drawing.Color.White
        Me.tickIntervalEditor.Location = New System.Drawing.Point(13, 80)
        Me.tickIntervalEditor.Name = "tickIntervalEditor"
        Me.tickIntervalEditor.NumericType = Infragistics.Win.UltraWinEditors.NumericType.[Double]
        Me.tickIntervalEditor.Size = New System.Drawing.Size(104, 21)
        Me.tickIntervalEditor.TabIndex = 32
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(15, 66)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(114, 13)
        Me.label2.TabIndex = 35
        Me.label2.Text = "Intervalo de Marca��o"
        '
        'tickmarkStyleEditor
        '
        Me.tickmarkStyleEditor.DropDownStyle = Infragistics.Win.DropDownStyle.DropDownList
        ValueListItem8.DataValue = "Smart"
        ValueListItem8.DisplayText = "Comprimido"
        ValueListItem9.DataValue = "Percentage"
        ValueListItem9.DisplayText = "Percentual"
        ValueListItem10.DataValue = "DataInterval"
        ValueListItem10.DisplayText = "Intervalo de Data"
        Me.tickmarkStyleEditor.Items.AddRange(New Infragistics.Win.ValueListItem() {ValueListItem8, ValueListItem9, ValueListItem10})
        Me.tickmarkStyleEditor.Location = New System.Drawing.Point(15, 37)
        Me.tickmarkStyleEditor.Name = "tickmarkStyleEditor"
        Me.tickmarkStyleEditor.Nullable = False
        Me.tickmarkStyleEditor.Size = New System.Drawing.Size(120, 21)
        Me.tickmarkStyleEditor.TabIndex = 31
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(15, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 14)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Tipo de Marca��o"
        '
        'cboModeloEstiloCor
        '
        Me.cboModeloEstiloCor.FormattingEnabled = True
        Me.cboModeloEstiloCor.Location = New System.Drawing.Point(6, 35)
        Me.cboModeloEstiloCor.Name = "cboModeloEstiloCor"
        Me.cboModeloEstiloCor.Size = New System.Drawing.Size(176, 21)
        Me.cboModeloEstiloCor.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Modelo de Estilo  de Cor"
        '
        'grpRolagem
        '
        Me.grpRolagem.Controls.Add(Me.chkRolagem)
        Me.grpRolagem.Controls.Add(Me.trbRolagemVertical)
        Me.grpRolagem.Controls.Add(Me.UltraLabel4)
        Me.grpRolagem.Controls.Add(Me.trbRolagemHorizontal)
        Me.grpRolagem.Controls.Add(Me.UltraLabel5)
        Me.grpRolagem.Location = New System.Drawing.Point(190, 273)
        Me.grpRolagem.Name = "grpRolagem"
        Me.grpRolagem.Size = New System.Drawing.Size(176, 165)
        Me.grpRolagem.TabIndex = 29
        Me.grpRolagem.TabStop = False
        Me.grpRolagem.Text = "Rolagem e Zoom (S� 2D)"
        '
        'chkRolagem
        '
        Me.chkRolagem.Location = New System.Drawing.Point(10, 20)
        Me.chkRolagem.Name = "chkRolagem"
        Me.chkRolagem.Size = New System.Drawing.Size(160, 24)
        Me.chkRolagem.TabIndex = 11
        Me.chkRolagem.Text = "Ativar Rolagem e Zoom"
        '
        'trbRolagemVertical
        '
        Me.trbRolagemVertical.Location = New System.Drawing.Point(6, 117)
        Me.trbRolagemVertical.Maximum = 100
        Me.trbRolagemVertical.Name = "trbRolagemVertical"
        Me.trbRolagemVertical.Size = New System.Drawing.Size(155, 45)
        Me.trbRolagemVertical.TabIndex = 10
        Me.trbRolagemVertical.TickFrequency = 10
        '
        'UltraLabel4
        '
        Me.UltraLabel4.Location = New System.Drawing.Point(10, 99)
        Me.UltraLabel4.Name = "UltraLabel4"
        Me.UltraLabel4.Size = New System.Drawing.Size(100, 23)
        Me.UltraLabel4.TabIndex = 9
        Me.UltraLabel4.Text = "Escala Vertical:"
        '
        'trbRolagemHorizontal
        '
        Me.trbRolagemHorizontal.Location = New System.Drawing.Point(6, 64)
        Me.trbRolagemHorizontal.Maximum = 100
        Me.trbRolagemHorizontal.Name = "trbRolagemHorizontal"
        Me.trbRolagemHorizontal.Size = New System.Drawing.Size(155, 45)
        Me.trbRolagemHorizontal.TabIndex = 8
        Me.trbRolagemHorizontal.TickFrequency = 10
        '
        'UltraLabel5
        '
        Me.UltraLabel5.Location = New System.Drawing.Point(10, 44)
        Me.UltraLabel5.Name = "UltraLabel5"
        Me.UltraLabel5.Size = New System.Drawing.Size(100, 23)
        Me.UltraLabel5.TabIndex = 7
        Me.UltraLabel5.Text = "Escala Horizontal:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkLinhaHorizontalMenor)
        Me.GroupBox1.Controls.Add(Me.chkLinhaVerticalMenor)
        Me.GroupBox1.Controls.Add(Me.chkLinhaVerticalMaior)
        Me.GroupBox1.Controls.Add(Me.chkLinhaHorizontalMaior)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 523)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(176, 125)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Linha de Grade"
        '
        'chkLinhaHorizontalMenor
        '
        Me.chkLinhaHorizontalMenor.AutoSize = True
        Me.chkLinhaHorizontalMenor.Location = New System.Drawing.Point(15, 50)
        Me.chkLinhaHorizontalMenor.Name = "chkLinhaHorizontalMenor"
        Me.chkLinhaHorizontalMenor.Size = New System.Drawing.Size(135, 17)
        Me.chkLinhaHorizontalMenor.TabIndex = 3
        Me.chkLinhaHorizontalMenor.Text = "Linha Horizontal Menor"
        Me.chkLinhaHorizontalMenor.UseVisualStyleBackColor = True
        '
        'chkLinhaVerticalMenor
        '
        Me.chkLinhaVerticalMenor.AutoSize = True
        Me.chkLinhaVerticalMenor.Location = New System.Drawing.Point(15, 100)
        Me.chkLinhaVerticalMenor.Name = "chkLinhaVerticalMenor"
        Me.chkLinhaVerticalMenor.Size = New System.Drawing.Size(123, 17)
        Me.chkLinhaVerticalMenor.TabIndex = 2
        Me.chkLinhaVerticalMenor.Text = "Linha Vertical Menor"
        Me.chkLinhaVerticalMenor.UseVisualStyleBackColor = True
        '
        'chkLinhaVerticalMaior
        '
        Me.chkLinhaVerticalMaior.AutoSize = True
        Me.chkLinhaVerticalMaior.Location = New System.Drawing.Point(15, 75)
        Me.chkLinhaVerticalMaior.Name = "chkLinhaVerticalMaior"
        Me.chkLinhaVerticalMaior.Size = New System.Drawing.Size(119, 17)
        Me.chkLinhaVerticalMaior.TabIndex = 1
        Me.chkLinhaVerticalMaior.Text = "Linha Vertical Maior"
        Me.chkLinhaVerticalMaior.UseVisualStyleBackColor = True
        '
        'chkLinhaHorizontalMaior
        '
        Me.chkLinhaHorizontalMaior.AutoSize = True
        Me.chkLinhaHorizontalMaior.Location = New System.Drawing.Point(15, 25)
        Me.chkLinhaHorizontalMaior.Name = "chkLinhaHorizontalMaior"
        Me.chkLinhaHorizontalMaior.Size = New System.Drawing.Size(131, 17)
        Me.chkLinhaHorizontalMaior.TabIndex = 0
        Me.chkLinhaHorizontalMaior.Text = "Linha Horizontal Maior"
        Me.chkLinhaHorizontalMaior.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.trbEscala_Perspectiva)
        Me.GroupBox4.Controls.Add(Me.label9)
        Me.GroupBox4.Controls.Add(Me.label10)
        Me.GroupBox4.Controls.Add(Me.trbEscala_Escala)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 380)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(176, 135)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Escala (S� para gr�ficos 3D)"
        '
        'trbEscala_Perspectiva
        '
        Me.trbEscala_Perspectiva.Location = New System.Drawing.Point(10, 83)
        Me.trbEscala_Perspectiva.Maximum = 100
        Me.trbEscala_Perspectiva.Name = "trbEscala_Perspectiva"
        Me.trbEscala_Perspectiva.Size = New System.Drawing.Size(151, 45)
        Me.trbEscala_Perspectiva.TabIndex = 18
        Me.trbEscala_Perspectiva.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(15, 67)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(80, 16)
        Me.label9.TabIndex = 16
        Me.label9.Text = "Perspectiva"
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(15, 19)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(48, 16)
        Me.label10.TabIndex = 15
        Me.label10.Text = "Escala"
        '
        'trbEscala_Escala
        '
        Me.trbEscala_Escala.Location = New System.Drawing.Point(10, 35)
        Me.trbEscala_Escala.Maximum = 100
        Me.trbEscala_Escala.Name = "trbEscala_Escala"
        Me.trbEscala_Escala.Size = New System.Drawing.Size(151, 45)
        Me.trbEscala_Escala.TabIndex = 17
        Me.trbEscala_Escala.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label0)
        Me.GroupBox2.Controls.Add(Me.ultraLabel6)
        Me.GroupBox2.Controls.Add(Me.trbExtensao_Horizontal)
        Me.GroupBox2.Controls.Add(Me.trbExtensao_Vertical)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 64)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(176, 137)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Extens�o"
        '
        'Label0
        '
        Appearance3.TextVAlignAsString = "Middle"
        Me.Label0.Appearance = Appearance3
        Me.Label0.Location = New System.Drawing.Point(6, 68)
        Me.Label0.Name = "Label0"
        Me.Label0.Size = New System.Drawing.Size(95, 16)
        Me.Label0.TabIndex = 27
        Me.Label0.Text = "Extens�o Vertical"
        '
        'ultraLabel6
        '
        Appearance4.TextVAlignAsString = "Middle"
        Me.ultraLabel6.Appearance = Appearance4
        Me.ultraLabel6.Location = New System.Drawing.Point(6, 20)
        Me.ultraLabel6.Name = "ultraLabel6"
        Me.ultraLabel6.Size = New System.Drawing.Size(108, 16)
        Me.ultraLabel6.TabIndex = 26
        Me.ultraLabel6.Text = "Extens�o Horizontal"
        '
        'trbExtensao_Horizontal
        '
        Me.trbExtensao_Horizontal.Location = New System.Drawing.Point(10, 39)
        Me.trbExtensao_Horizontal.Maximum = 100
        Me.trbExtensao_Horizontal.Name = "trbExtensao_Horizontal"
        Me.trbExtensao_Horizontal.Size = New System.Drawing.Size(149, 45)
        Me.trbExtensao_Horizontal.TabIndex = 25
        Me.trbExtensao_Horizontal.TickFrequency = 5
        Me.trbExtensao_Horizontal.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'trbExtensao_Vertical
        '
        Me.trbExtensao_Vertical.Location = New System.Drawing.Point(10, 87)
        Me.trbExtensao_Vertical.Maximum = 100
        Me.trbExtensao_Vertical.Name = "trbExtensao_Vertical"
        Me.trbExtensao_Vertical.Size = New System.Drawing.Size(149, 45)
        Me.trbExtensao_Vertical.TabIndex = 28
        Me.trbExtensao_Vertical.TickFrequency = 5
        Me.trbExtensao_Vertical.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'grpRotacao
        '
        Me.grpRotacao.Controls.Add(Me.UltraLabel3)
        Me.grpRotacao.Controls.Add(Me.UltraLabel2)
        Me.grpRotacao.Controls.Add(Me.UltraLabel1)
        Me.grpRotacao.Controls.Add(Me.trbRotacaoGiratoria)
        Me.grpRotacao.Controls.Add(Me.trbRotacaoHorizontal)
        Me.grpRotacao.Controls.Add(Me.trbRotacaoVertical)
        Me.grpRotacao.Location = New System.Drawing.Point(6, 207)
        Me.grpRotacao.Name = "grpRotacao"
        Me.grpRotacao.Size = New System.Drawing.Size(176, 165)
        Me.grpRotacao.TabIndex = 27
        Me.grpRotacao.TabStop = False
        Me.grpRotacao.Text = "Rota��o (S� para gr�ficos 3D)"
        '
        'UltraLabel3
        '
        Appearance5.TextVAlignAsString = "Middle"
        Me.UltraLabel3.Appearance = Appearance5
        Me.UltraLabel3.Location = New System.Drawing.Point(16, 109)
        Me.UltraLabel3.Name = "UltraLabel3"
        Me.UltraLabel3.Size = New System.Drawing.Size(108, 16)
        Me.UltraLabel3.TabIndex = 29
        Me.UltraLabel3.Text = "Rota��o Girat�ria"
        '
        'UltraLabel2
        '
        Appearance6.TextVAlignAsString = "Middle"
        Me.UltraLabel2.Appearance = Appearance6
        Me.UltraLabel2.Location = New System.Drawing.Point(16, 19)
        Me.UltraLabel2.Name = "UltraLabel2"
        Me.UltraLabel2.Size = New System.Drawing.Size(108, 16)
        Me.UltraLabel2.TabIndex = 28
        Me.UltraLabel2.Text = "Rota��o Vertical"
        '
        'UltraLabel1
        '
        Appearance7.TextVAlignAsString = "Middle"
        Me.UltraLabel1.Appearance = Appearance7
        Me.UltraLabel1.Location = New System.Drawing.Point(16, 64)
        Me.UltraLabel1.Name = "UltraLabel1"
        Me.UltraLabel1.Size = New System.Drawing.Size(108, 16)
        Me.UltraLabel1.TabIndex = 27
        Me.UltraLabel1.Text = "Rota��o Horizontal"
        '
        'trbRotacaoGiratoria
        '
        Me.trbRotacaoGiratoria.Location = New System.Drawing.Point(10, 117)
        Me.trbRotacaoGiratoria.Maximum = 180
        Me.trbRotacaoGiratoria.Minimum = -180
        Me.trbRotacaoGiratoria.Name = "trbRotacaoGiratoria"
        Me.trbRotacaoGiratoria.Size = New System.Drawing.Size(151, 45)
        Me.trbRotacaoGiratoria.TabIndex = 13
        Me.trbRotacaoGiratoria.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'trbRotacaoHorizontal
        '
        Me.trbRotacaoHorizontal.Location = New System.Drawing.Point(10, 83)
        Me.trbRotacaoHorizontal.Maximum = 180
        Me.trbRotacaoHorizontal.Minimum = -180
        Me.trbRotacaoHorizontal.Name = "trbRotacaoHorizontal"
        Me.trbRotacaoHorizontal.Size = New System.Drawing.Size(151, 45)
        Me.trbRotacaoHorizontal.TabIndex = 12
        Me.trbRotacaoHorizontal.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'trbRotacaoVertical
        '
        Me.trbRotacaoVertical.Location = New System.Drawing.Point(10, 35)
        Me.trbRotacaoVertical.Maximum = 180
        Me.trbRotacaoVertical.Minimum = -180
        Me.trbRotacaoVertical.Name = "trbRotacaoVertical"
        Me.trbRotacaoVertical.Size = New System.Drawing.Size(151, 45)
        Me.trbRotacaoVertical.TabIndex = 11
        Me.trbRotacaoVertical.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'UltraDockManager1
        '
        Me.UltraDockManager1.AnimationSpeed = Infragistics.Win.UltraWinDock.AnimationSpeed.StandardSpeedPlus5
        DockableControlPane1.Control = Me.grpPropriedades
        DockableControlPane1.FlyoutSize = New System.Drawing.Size(379, -1)
        DockableControlPane1.OriginalControlBounds = New System.Drawing.Rectangle(258, 44, 190, 833)
        DockableControlPane1.Pinned = False
        DockableControlPane1.Size = New System.Drawing.Size(100, 100)
        DockableControlPane1.Text = "Propriedades"
        DockAreaPane1.Panes.AddRange(New Infragistics.Win.UltraWinDock.DockablePaneBase() {DockableControlPane1})
        DockAreaPane1.Size = New System.Drawing.Size(380, 884)
        Me.UltraDockManager1.DockAreas.AddRange(New Infragistics.Win.UltraWinDock.DockAreaPane() {DockAreaPane1})
        Me.UltraDockManager1.HostControl = Me
        Me.UltraDockManager1.WindowStyle = Infragistics.Win.UltraWinDock.WindowStyle.Office2003
        '
        '_frmChart_PropriedadeUnpinnedTabAreaLeft
        '
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Dock = System.Windows.Forms.DockStyle.Left
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Location = New System.Drawing.Point(0, 0)
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Name = "_frmChart_PropriedadeUnpinnedTabAreaLeft"
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Owner = Me.UltraDockManager1
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.Size = New System.Drawing.Size(0, 783)
        Me._frmChart_PropriedadeUnpinnedTabAreaLeft.TabIndex = 87
        '
        '_frmChart_PropriedadeUnpinnedTabAreaRight
        '
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Dock = System.Windows.Forms.DockStyle.Right
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Location = New System.Drawing.Point(649, 0)
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Name = "_frmChart_PropriedadeUnpinnedTabAreaRight"
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Owner = Me.UltraDockManager1
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.Size = New System.Drawing.Size(21, 783)
        Me._frmChart_PropriedadeUnpinnedTabAreaRight.TabIndex = 88
        '
        '_frmChart_PropriedadeUnpinnedTabAreaTop
        '
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Dock = System.Windows.Forms.DockStyle.Top
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Location = New System.Drawing.Point(0, 0)
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Name = "_frmChart_PropriedadeUnpinnedTabAreaTop"
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Owner = Me.UltraDockManager1
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.Size = New System.Drawing.Size(649, 0)
        Me._frmChart_PropriedadeUnpinnedTabAreaTop.TabIndex = 89
        '
        '_frmChart_PropriedadeUnpinnedTabAreaBottom
        '
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Location = New System.Drawing.Point(0, 783)
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Name = "_frmChart_PropriedadeUnpinnedTabAreaBottom"
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Owner = Me.UltraDockManager1
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.Size = New System.Drawing.Size(649, 0)
        Me._frmChart_PropriedadeUnpinnedTabAreaBottom.TabIndex = 90
        '
        '_frmChart_PropriedadeAutoHideControl
        '
        Me._frmChart_PropriedadeAutoHideControl.Controls.Add(Me.DockableWindow1)
        Me._frmChart_PropriedadeAutoHideControl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._frmChart_PropriedadeAutoHideControl.Location = New System.Drawing.Point(265, 0)
        Me._frmChart_PropriedadeAutoHideControl.Name = "_frmChart_PropriedadeAutoHideControl"
        Me._frmChart_PropriedadeAutoHideControl.Owner = Me.UltraDockManager1
        Me._frmChart_PropriedadeAutoHideControl.Size = New System.Drawing.Size(384, 884)
        Me._frmChart_PropriedadeAutoHideControl.TabIndex = 91
        '
        'DockableWindow1
        '
        Me.DockableWindow1.Controls.Add(Me.grpPropriedades)
        Me.DockableWindow1.Location = New System.Drawing.Point(5, 0)
        Me.DockableWindow1.Name = "DockableWindow1"
        Me.DockableWindow1.Owner = Me.UltraDockManager1
        Me.DockableWindow1.Size = New System.Drawing.Size(379, 884)
        Me.DockableWindow1.TabIndex = 96
        '
        'WindowDockingArea1
        '
        Me.WindowDockingArea1.Dock = System.Windows.Forms.DockStyle.Right
        Me.WindowDockingArea1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WindowDockingArea1.Location = New System.Drawing.Point(264, 0)
        Me.WindowDockingArea1.Name = "WindowDockingArea1"
        Me.WindowDockingArea1.Owner = Me.UltraDockManager1
        Me.WindowDockingArea1.Size = New System.Drawing.Size(385, 884)
        Me.WindowDockingArea1.TabIndex = 94
        '
        'frmChart_Propriedade
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(670, 783)
        Me.Controls.Add(Me._frmChart_PropriedadeAutoHideControl)
        Me.Controls.Add(Me.WindowDockingArea1)
        Me.Controls.Add(Me._frmChart_PropriedadeUnpinnedTabAreaTop)
        Me.Controls.Add(Me._frmChart_PropriedadeUnpinnedTabAreaBottom)
        Me.Controls.Add(Me._frmChart_PropriedadeUnpinnedTabAreaLeft)
        Me.Controls.Add(Me._frmChart_PropriedadeUnpinnedTabAreaRight)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "frmChart_Propriedade"
        Me.Text = "Gr�fico"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.grpPropriedades, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPropriedades.ResumeLayout(False)
        Me.grpPropriedades.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.tickPercentageEditor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tickIntervalTypeEditor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tickIntervalEditor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tickmarkStyleEditor, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRolagem.ResumeLayout(False)
        Me.grpRolagem.PerformLayout()
        CType(Me.trbRolagemVertical, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbRolagemHorizontal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.trbEscala_Perspectiva, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbEscala_Escala, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.trbExtensao_Horizontal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbExtensao_Vertical, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRotacao.ResumeLayout(False)
        Me.grpRotacao.PerformLayout()
        CType(Me.trbRotacaoGiratoria, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbRotacaoHorizontal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trbRotacaoVertical, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UltraDockManager1, System.ComponentModel.ISupportInitialize).EndInit()
        Me._frmChart_PropriedadeAutoHideControl.ResumeLayout(False)
        Me.DockableWindow1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboModeloEstiloCor As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkLinhaHorizontalMenor As System.Windows.Forms.CheckBox
    Friend WithEvents chkLinhaVerticalMenor As System.Windows.Forms.CheckBox
    Friend WithEvents chkLinhaVerticalMaior As System.Windows.Forms.CheckBox
    Friend WithEvents chkLinhaHorizontalMaior As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents ultraLabel6 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents trbExtensao_Horizontal As System.Windows.Forms.TrackBar
    Private WithEvents trbExtensao_Vertical As System.Windows.Forms.TrackBar
    Private WithEvents Label0 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents grpRotacao As System.Windows.Forms.GroupBox
    Private WithEvents trbRotacaoGiratoria As System.Windows.Forms.TrackBar
    Private WithEvents trbRotacaoHorizontal As System.Windows.Forms.TrackBar
    Private WithEvents trbRotacaoVertical As System.Windows.Forms.TrackBar
    Private WithEvents UltraLabel3 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents UltraLabel2 As Infragistics.Win.Misc.UltraLabel
    Private WithEvents UltraLabel1 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Private WithEvents trbEscala_Perspectiva As System.Windows.Forms.TrackBar
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents trbEscala_Escala As System.Windows.Forms.TrackBar
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents grpRolagem As System.Windows.Forms.GroupBox
    Private WithEvents chkRolagem As System.Windows.Forms.CheckBox
    Friend WithEvents trbRolagemVertical As System.Windows.Forms.TrackBar
    Friend WithEvents UltraLabel4 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents trbRolagemHorizontal As System.Windows.Forms.TrackBar
    Friend WithEvents UltraLabel5 As Infragistics.Win.Misc.UltraLabel
    Friend WithEvents grpPropriedades As Infragistics.Win.Misc.UltraGroupBox
    Friend WithEvents UltraDockManager1 As Infragistics.Win.UltraWinDock.UltraDockManager
    Friend WithEvents _frmChart_PropriedadeAutoHideControl As Infragistics.Win.UltraWinDock.AutoHideControl
    Friend WithEvents _frmChart_PropriedadeUnpinnedTabAreaTop As Infragistics.Win.UltraWinDock.UnpinnedTabArea
    Friend WithEvents _frmChart_PropriedadeUnpinnedTabAreaBottom As Infragistics.Win.UltraWinDock.UnpinnedTabArea
    Friend WithEvents _frmChart_PropriedadeUnpinnedTabAreaLeft As Infragistics.Win.UltraWinDock.UnpinnedTabArea
    Friend WithEvents _frmChart_PropriedadeUnpinnedTabAreaRight As Infragistics.Win.UltraWinDock.UnpinnedTabArea
    Friend WithEvents DockableWindow1 As Infragistics.Win.UltraWinDock.DockableWindow
    Friend WithEvents WindowDockingArea1 As Infragistics.Win.UltraWinDock.WindowDockingArea
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents tickPercentageEditor As Infragistics.Win.UltraWinEditors.UltraNumericEditor
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents tickIntervalTypeEditor As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents tickIntervalEditor As Infragistics.Win.UltraWinEditors.UltraNumericEditor
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents tickmarkStyleEditor As Infragistics.Win.UltraWinEditors.UltraComboEditor
    Private WithEvents Label5 As System.Windows.Forms.Label
End Class
