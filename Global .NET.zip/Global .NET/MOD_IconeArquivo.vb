Imports Microsoft.VisualBasic.Compatibility

Module MOD_IconeArquivo

    Public Function GetIconAsImageForFileType(ByVal FileExt As String, ByVal IconWidth As Integer, ByVal IconHeight As Integer)

        'Get the file extension from the given file path, 
        'The file path does not have to point to a real file, no file exists check takes place.
        'If you dont have a file path then just make one up with the necessary file extension.
        ' Dim FileExt As String = Mid(My.Computer.FileSystem.GetName(FilePath), _
        ' InStrRev(My.Computer.FileSystem.GetName(FilePath), "."))

tryagain:
        FileExt = "." & FileExt

        'Create a random file name
        Dim tempfile As String = "ExtractIcone" & FileExt
        Dim FSw As IO.FileStream

        If Not My.Computer.FileSystem.FileExists(tempfile) Then
            'Create a temp file that has the necessary file extension
            FSw = New IO.FileStream(My.Computer.FileSystem.SpecialDirectories.Temp & "\" & _
            tempfile, IO.FileMode.Create, IO.FileAccess.Write)
            FSw.Close()
        End If

        'Get the default icon for the temporary file and save it as a bitmap
        Dim ABitmap As Bitmap = GetIconAsImageFromFile(My.Computer.FileSystem.SpecialDirectories.Temp & "\" & _
                                                        tempfile, IconWidth, IconHeight)

        'end function and return the bitmap
        Return ABitmap

        'delete teh temporary file
        Try
            My.Computer.FileSystem.DeleteFile(tempfile)
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try

        FileExt = Nothing
        tempfile = Nothing
        ABitmap = Nothing

    End Function

    Public Function GetIconAsImageFromFile(ByVal FilePath As String, ByVal IconWidth As Integer, ByVal IconHeight As Integer)

        Dim myIcon As System.Drawing.Icon = Icon.ExtractAssociatedIcon(FilePath)
        Dim ABitmap As New Bitmap(myIcon.ToBitmap(), CInt(IconWidth), CInt(IconHeight))

        Return ABitmap

        myIcon = Nothing
        ABitmap = Nothing

    End Function

    Public Function GetRandomString(ByVal NumberOfChars As Integer)

        If NumberOfChars <= 1 Then
            Return ""
            Exit Function
        End If

        Dim RandomString As String = ""
        Dim Rand As New Random
        Dim CharArray() As Char = New Char(35) {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", _
        "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", _
        "8", "9"}

        For x As Integer = 0 To NumberOfChars
            RandomString = RandomString & CharArray(Rand.Next(0, 34))
        Next

        Return RandomString

        RandomString = Nothing
        Rand = Nothing
        Erase CharArray

    End Function



End Module
