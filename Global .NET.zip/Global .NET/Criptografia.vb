Imports System.Text
Imports System.IO
Imports System.Security.Cryptography

Module Criptografia
    Public Criptografia_ChaveSecreta As String = "0928734561!@#$%�&*"

    '   *********************************************************************
    '   ***** Fun��o respons�vel por Cifrar a sua String                *****
    '   ***** Use da seguinte forma:                                    *****
    '   ***** Call Cifrar("Palavra", "SuaChaveSecreta(Ex.2345)")        *****
    '   *********************************************************************

    Public Function Criptografia_Cifrar(ByVal vstrTextToBeEncrypted As String, ByVal vstrEncryptionKey As String) As String

        Dim bytValue() As Byte
        Dim bytKey() As Byte
        Dim bytEncoded() As Byte
        Dim bytIV() As Byte = {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}
        Dim intLength As Integer
        Dim intRemaining As Integer
        Dim objMemoryStream As New MemoryStream
        Dim objCryptoStream As CryptoStream
        Dim objRijndaelManaged As RijndaelManaged


        '   **********************************************************************
        '   ****** Descarta todos os caracteres nulos da palavra a ser cifrada****  
        '   **********************************************************************
        vstrTextToBeEncrypted = TiraCaracteresNulos(vstrTextToBeEncrypted)

        '   **********************************************************************
        '   ******  O valor deve estar dentro da tabela ASCII (i.e., no DBCS chars)
        '   **********************************************************************

        bytValue = Encoding.ASCII.GetBytes(vstrTextToBeEncrypted.ToCharArray)
        intLength = Len(vstrEncryptionKey)

        '   ********************************************************************
        '   ******   A chave cifrada ser� de 256 bits long (32 bytes)     ******
        '   ******   Se for maior que 32 bytes ent�o ser� truncado.       ******
        '   ******   Se for menor que 32 bytes ser� alocado.              ******
        '   ******   Usando upper-case Xs.                                ****** 
        '   ********************************************************************

        If intLength >= 32 Then
            vstrEncryptionKey = Strings.Left(vstrEncryptionKey, 32)
        Else
            intLength = Len(vstrEncryptionKey)
            intRemaining = 32 - intLength
            vstrEncryptionKey = vstrEncryptionKey & Strings.StrDup(intRemaining, "X")
        End If

        bytKey = Encoding.ASCII.GetBytes(vstrEncryptionKey.ToCharArray)
        objRijndaelManaged = New RijndaelManaged

        '   ***********************************************************************
        '   ******  Cria o valor a ser crifrado e depois escreve             ******
        '   ******  Convertido em uma disposi��o do byte                     ******
        '   ***********************************************************************

        Try

            objCryptoStream = New CryptoStream(objMemoryStream, objRijndaelManaged.CreateEncryptor(bytKey, bytIV), CryptoStreamMode.Write)
            objCryptoStream.Write(bytValue, 0, bytValue.Length)

            objCryptoStream.FlushFinalBlock()

            bytEncoded = objMemoryStream.ToArray
            objMemoryStream.Close()
            objCryptoStream.Close()
        Catch

        End Try

        '   ***********************************************************************
        '   ****** Retorna o valor cifrado (convertido de byte para base64 )  *****
        '   ***********************************************************************
        Return Convert.ToBase64String(bytEncoded)
    End Function

    '   *********************************************************************
    '   ***** Fun��o Respons�vel por Decifrar a sua String Cifrada       *****
    '   ***** Use da seguinte forma:                                    *****
    '   ***** Call Decifrar("Palavra", "SuaChaveSecreta(Ex.2345)")      *****
    '   *********************************************************************

    Public Function Criptografia_Decifrar(ByVal vstrStringToBeDecrypted As String, ByVal vstrDecryptionKey As String) As String
        Dim bytDataToBeDecrypted() As Byte
        Dim bytTemp() As Byte
        Dim bytIV() As Byte = {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}
        Dim objRijndaelManaged As New RijndaelManaged
        Dim objMemoryStream As MemoryStream
        Dim objCryptoStream As CryptoStream
        Dim bytDecryptionKey() As Byte

        Dim intLength As Integer
        Dim intRemaining As Integer
        Dim intCtr As Integer
        Dim strReturnString As String = String.Empty
        Dim achrCharacterArray() As Char
        Dim intIndex As Integer

        '   *****************************************************************
        '   ******   Convert base64 cifrada para byte array            ******
        '   ******   Convert base64 cifrada para byte array            ******
        '   *****************************************************************
        bytDataToBeDecrypted = Convert.FromBase64String(vstrStringToBeDecrypted)

        '   ********************************************************************
        '   ******   A chave cifrada sera de 256 bits long (32 bytes)     ******
        '   ******   Se for maior que 32 bytes ent�o ser� truncado.       ******
        '   ******   Se for menor que 32 bytes ser� alocado.              ******
        '   ******   Usando upper-case Xs.                                ****** 
        '   ********************************************************************
        intLength = Len(vstrDecryptionKey)

        If intLength >= 32 Then
            vstrDecryptionKey = Strings.Left(vstrDecryptionKey, 32)
        Else
            intLength = Len(vstrDecryptionKey)
            intRemaining = 32 - intLength
            vstrDecryptionKey = vstrDecryptionKey & Strings.StrDup(intRemaining, "X")
        End If

        bytDecryptionKey = Encoding.ASCII.GetBytes(vstrDecryptionKey.ToCharArray)

        ReDim bytTemp(bytDataToBeDecrypted.Length)

        objMemoryStream = New MemoryStream(bytDataToBeDecrypted)

        '   ***********************************************************************
        '   ******  Escrever o valor decifrado depois que � convertido       ******
        '   ***********************************************************************

        Try

            objCryptoStream = New CryptoStream(objMemoryStream, _
               objRijndaelManaged.CreateDecryptor(bytDecryptionKey, bytIV), _
               CryptoStreamMode.Read)

            objCryptoStream.Read(bytTemp, 0, bytTemp.Length)

            objCryptoStream.FlushFinalBlock()
            objMemoryStream.Close()
            objCryptoStream.Close()

        Catch

        End Try

        '   ***********************************************************************
        '   ******  Retorna o valor decifrado                                ******
        '   ***********************************************************************
        Return TiraCaracteresNulos(Encoding.ASCII.GetString(bytTemp))
    End Function

    '   *********************************************************************
    '   ***** Fun��o responvel por tirar os espa�os em branco da        *****
    '   ***** vari�vel a ser cifrada                                    *****
    '   ***** Esta fun��o � chamada internamente                        *****
    '   *********************************************************************

    Private Function TiraCaracteresNulos(ByVal vstrStringWithNulls As String) As String

        Dim intPosition As Integer
        Dim strStringWithOutNulls As String

        intPosition = 1
        strStringWithOutNulls = vstrStringWithNulls

        Do While intPosition > 0
            intPosition = InStr(intPosition, vstrStringWithNulls, vbNullChar)

            If intPosition > 0 Then
                strStringWithOutNulls = Left$(strStringWithOutNulls, intPosition - 1) & _
                                  Right$(strStringWithOutNulls, Len(strStringWithOutNulls) - intPosition)
            End If

            If intPosition > strStringWithOutNulls.Length Then
                Exit Do
            End If
        Loop

        Return strStringWithOutNulls
    End Function
End Module